#!/usr/bin/env python3
"""
ETF/Stock Portfolio Balancer - desktop entry point.

Runs the local FastAPI backend on a random loopback port and shows it in a
native webview window (pywebview), which uses whatever engine the OS already
has: WebView2 on Windows, WKWebView on macOS, WebKitGTK on Linux. That keeps
the app a pure-Python install with no Node, Electron or Rust toolchain, and
it is why the same code runs on all three platforms.

If pywebview or its platform runtime is unavailable, this falls back to
opening the default browser against the same local server, so the app still
works everywhere.

    python app.py                # native window
    python app.py --browser      # force the browser
    python app.py --port 8765    # pin the port
"""

from __future__ import annotations

import argparse
import socket
import sys
import threading
import time
import webbrowser

import uvicorn

from balancer.server import app as fastapi_app

WINDOW_TITLE = "ETF/Stock Portfolio Balancer"


def free_port(preferred: int = 0) -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", preferred))
        return s.getsockname()[1]


def serve(port: int) -> threading.Thread:
    cfg = uvicorn.Config(fastapi_app, host="127.0.0.1", port=port,
                         log_level="warning")
    server = uvicorn.Server(cfg)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    return t


def wait_until_up(port: int, timeout: float = 20.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.1)
    return False


# Tall by default: the workflow is a five-step column, and a short window
# means scrolling past the plan to reach the execute buttons.
PREFERRED_W, PREFERRED_H = 1180, 1200


def window_size() -> tuple:
    """Preferred size, clamped to the display so the window cannot open with
    its lower half (the execute controls) off-screen."""
    w, h = PREFERRED_W, PREFERRED_H
    try:
        import webview
        screens = getattr(webview, "screens", None) or []
        if screens:
            sw, sh = screens[0].width, screens[0].height
            # leave room for a taskbar/dock and window chrome
            w = min(w, max(900, sw - 80))
            h = min(h, max(640, sh - 120))
    except Exception:
        pass
    return w, h


def main() -> int:
    ap = argparse.ArgumentParser(description=WINDOW_TITLE)
    ap.add_argument("--port", type=int, default=0,
                    help="port for the local server (default: random free)")
    ap.add_argument("--browser", action="store_true",
                    help="open in the default browser instead of a window")
    args = ap.parse_args()

    port = free_port(args.port)
    serve(port)
    if not wait_until_up(port):
        print("The local server did not start.", file=sys.stderr)
        return 1

    url = f"http://127.0.0.1:{port}/"
    print(f"{WINDOW_TITLE} running at {url}")

    if not args.browser:
        try:
            import webview          # pywebview
            w, h = window_size()
            webview.create_window(WINDOW_TITLE, url, width=w, height=h,
                                  min_size=(900, 640))
            webview.start()
            return 0
        except ImportError:
            print("pywebview not installed; opening the browser instead.\n"
                  "  pip install pywebview")
        except Exception as exc:
            # A missing platform runtime (e.g. no WebKitGTK) lands here.
            print(f"Could not open a native window ({exc}); using the browser.")

    webbrowser.open(url)
    print("Close this window (Ctrl+C) to quit.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
