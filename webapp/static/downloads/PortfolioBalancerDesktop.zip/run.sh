#!/usr/bin/env bash
# ---------------------------------------------------------------------
# macOS / Linux launcher.
#
# Same interpreter-detection problem as the Windows script, in a milder form:
# `python3` is right almost everywhere, but not on distros or pyenv setups
# where only `python` exists. Try both and fail with a sentence rather than
# with "command not found" followed by a broken venv path.
# ---------------------------------------------------------------------
set -e
cd "$(dirname "$0")"

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(sys.version_info < (3, 9))' 2>/dev/null; then
    PY="$c"
    break
  fi
done
if [ -z "$PY" ]; then
  echo
  echo "  Could not find Python 3.9+. Tried: python3, python"
  echo "  Install it from your package manager or https://www.python.org/downloads/"
  echo
  exit 1
fi

if [ ! -x .venv/bin/python ]; then
  echo "Creating virtual environment using $PY ..."
  "$PY" -m venv .venv
fi
# Check the result, not the exit code -- see the note in run.bat.
if [ ! -x .venv/bin/python ]; then
  echo
  echo "  Failed to create the virtual environment in .venv"
  echo "  Try running this by hand to see the reason:"
  echo "      $PY -m venv .venv"
  echo
  exit 1
fi

# A venv whose pip cannot run repairs itself, then rebuilds if that is not
# enough. See the long note in run.bat: pip upgrading ITSELF is what breaks,
# so there is deliberately no `pip install --upgrade pip` here.
if ! ./.venv/bin/python -m pip --version >/dev/null 2>&1; then
  echo "Pip in the virtual environment is not usable - repairing ..."
  ./.venv/bin/python -m ensurepip --upgrade || true
fi
if ! ./.venv/bin/python -m pip --version >/dev/null 2>&1; then
  echo "Repair did not take - rebuilding the virtual environment ..."
  rm -rf .venv
  "$PY" -m venv .venv
fi
if ! ./.venv/bin/python -m pip --version >/dev/null 2>&1; then
  echo
  echo "  The virtual environment was created but pip does not work in it."
  echo "  Delete the .venv folder and run this again."
  echo
  exit 1
fi

# Install only when something is missing, so a normal start is not delayed.
if ! ./.venv/bin/python -c "import fastapi, uvicorn, requests" >/dev/null 2>&1; then
  echo "Installing dependencies ..."
  ./.venv/bin/python -m pip install --disable-pip-version-check \
      --no-warn-script-location -r requirements.txt
fi

exec ./.venv/bin/python app.py "$@"
