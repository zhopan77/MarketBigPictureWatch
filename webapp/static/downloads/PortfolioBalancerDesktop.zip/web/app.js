/* ETF Portfolio Balancer - UI logic.
 *
 * The flow is a deliberate ladder: connect -> pick account -> load target ->
 * compute plan -> execute. Each step only unlocks the next once it has
 * succeeded, so orders can never be sent from a half-filled form.
 */

const S = {
  brokers: [], broker: null, saved: {},
  accounts: [], planHash: "", paper: false,
  supportsLimit: true, hasSells: false, hasBuys: false, sellsRun: false,
  pollTimer: null,          // fill watcher; cleared on disconnect
};

const $ = id => document.getElementById(id);
const money = v => (v < 0 ? "-$" : "$") + Math.abs(v).toLocaleString(
  undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const esc = s => String(s).replace(/[&<>"]/g,
  c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

async function api(path, body) {
  const res = await fetch(path, {
    method: body === undefined ? "GET" : "POST",
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { detail: text }; }
  if (!res.ok) throw new Error(data.detail || res.statusText);
  return data;
}

/* Mark a button as working: disable it and swap its label, while CSS spins a
 * ring in front of the text. Returns the function that restores it -- always
 * called from a finally block, so a thrown error cannot leave a button stuck
 * spinning with no way to retry. */
function busy(btn, label) {
  const original = btn.textContent;
  const wasDisabled = btn.disabled;
  btn.disabled = true;
  btn.classList.add("is-busy");
  btn.textContent = label + "\u2026";
  return () => {
    btn.textContent = original;
    btn.classList.remove("is-busy");
    btn.disabled = wasDisabled;
  };
}

function setMsg(id, text, kind = "") {
  const el = $(id);
  if (!el) return;                 // panel may not exist in every step
  el.textContent = text;
  el.className = "msg" + (kind ? " " + kind : "");
  el.hidden = !text;
}

/* ---------- step 1: broker ---------- */
async function loadBrokers() {
  const d = await api("/api/brokers");
  S.brokers = d.brokers;
  S.saved = d.saved || {};
  S.env = d.env || {};
  $("broker-picker").innerHTML = S.brokers.map(b => `
    <label class="pick ${b.available ? "" : "disabled"}">
      <input type="radio" name="broker" value="${b.key}"
             ${b.available ? "" : "disabled"}>
      <span class="pick-name">${esc(b.name)}</span>
      ${b.available ? "" : `<span class="pick-err">${esc(b.error)}</span>`}
    </label>`).join("");
  document.querySelectorAll('input[name="broker"]').forEach(r =>
    r.addEventListener("change", () => selectBroker(r.value)));

  const last = S.saved._last_broker;
  const first = (S.brokers.find(b => b.key === last && b.available)
                 || S.brokers.find(b => b.available));
  if (first) {
    document.querySelector(`input[name="broker"][value="${first.key}"]`).checked = true;
    selectBroker(first.key);
  }
}

function selectBroker(key) {
  const b = S.brokers.find(x => x.key === key);
  S.broker = b;
  S.supportsLimit = b.supports_limit;
  $("broker-blurb").textContent = b.blurb || "";
  const saved = S.saved[key] || {};

  $("broker-fields").innerHTML = b.fields.map(f => {
    /* Precedence: a REMEMBERED value wins, but only if it is non-empty.
     * `saved[f.key] ?? f.default` looks right and is not: ?? only falls
     * through on null/undefined, so a remembered EMPTY string (which is what
     * gets stored the moment someone ticks "Remember these settings" with a
     * field blank) beat the environment default and pinned the box empty
     * forever, with no way to recover except deleting settings.json. */
    const val = (saved[f.key] !== undefined && saved[f.key] !== "")
      ? saved[f.key] : (f.default ?? "");
    const common = `id="f-${f.key}" data-key="${f.key}"`;
    let input;
    if (f.kind === "select") {
      input = `<select ${common}>` + f.options.map(o =>
        `<option ${o === val ? "selected" : ""}>${esc(o)}</option>`).join("") +
        `</select>`;
    } else {
      input = `<input ${common} type="${f.kind === "password" ? "password"
        : f.kind === "number" ? "number" : "text"}" value="${esc(val)}">`;
    }
    return `<label class="field">
        <span class="flabel">${esc(f.label)}${f.required ? "" :
          ' <em class="opt">optional</em>'}</span>
        ${input}
        ${f.help ? `<span class="fhelp">${esc(f.help)}</span>` : ""}
      </label>`;
  }).join("");

  renderEnvHint(b);
  $("ts-helper").hidden = key !== "tradestation";
  $("remember").checked = !!S.saved[key];
  $("remember-secrets").checked = !!S.saved._remember_secrets;
  $("remember-secrets-wrap").hidden = !$("remember").checked;
}

/* One quiet line, and only when it earns its place.
 *
 * The first version reported per-VARIABLE and was wrong about it: every field
 * accepts several alias names, so with TS_API_KEY found it still listed
 * TRADESTATION_CLIENT_ID and TS_CLIENT_ID as "not visible" -- alarming, amber,
 * and meaningless, since only one of the three is ever needed. Report per
 * FIELD instead: a field is satisfied if ANY of its names supplied a value.
 *
 * Shown only when NOT ONE env-backed field was filled. A partial result is
 * normal and silent -- the TradeStation refresh token comes from the helper
 * below, not from the environment, so it is expected to be blank. */
function renderEnvHint(b) {
  const el = $("env-hint");
  if (!el) return;
  const vars = (S.env || {}).vars || {};
  const envFields = (b.fields || []).filter(f => (f.env || (f.env_alt || []).length));
  if (!envFields.length) { el.hidden = true; return; }

  const filled = envFields.filter(f => f.from_env);
  if (filled.length) { el.hidden = true; return; }   // something worked: say nothing

  /* A name differing only by whitespace or case renders identically in the
   * Windows dialog, so "not found" reads as a lie. Worth the extra clause. */
  const near = [];
  for (const f of envFields) {
    for (const n of [f.env, ...(f.env_alt || [])]) {
      for (const alt of ((vars[n] || {}).similar || [])) {
        if (!near.includes(alt)) near.push(alt);
      }
    }
  }
  el.hidden = false;
  el.textContent = "No environment variable found - please fill in manually."
    + (near.length
        ? ` (Close match found: ${near.join(", ")} - check for a trailing `
          + `space or different case in the name.)`
        : "");
}

function readConfig() {
  const cfg = {};
  document.querySelectorAll("#broker-fields [data-key]").forEach(el => {
    cfg[el.dataset.key] = el.value;
  });
  return cfg;
}

async function connect() {
  const done = busy($("btn-connect"), "Connecting");
  setMsg("connect-msg", "");
  try {
    const d = await api("/api/connect", {
      broker: S.broker.key, config: readConfig(),
      remember: $("remember").checked,
      remember_secrets: $("remember-secrets").checked,
    });
    S.accounts = d.accounts;
    S.paper = d.paper;
    S.supportsLimit = d.supports_limit;
    $("account-select").innerHTML = d.accounts.map(a =>
      `<option>${esc(a)}</option>`).join("");
    $("step-account").hidden = false;
    $("step-alloc").hidden = false;
    $("btn-disconnect").hidden = false;
    // If IB had to step past a client ID still held by TWS, say so rather
    // than letting the number silently differ from what was typed.
    const typed = parseInt(readConfig().client_id, 10);
    const stepped = (d.client_id != null && !Number.isNaN(typed)
                     && d.client_id !== typed)
      ? ` (client ID ${d.client_id}; ${typed} was still in use)` : "";
    setMsg("connect-msg",
           `Connected \u2014 ${d.accounts.length} account(s)${stepped}`, "ok");
    badge(S.paper ? "paper" : "live");
    if (!S.supportsLimit) {
      $("order-type").value = "MKT";
      $("order-type").disabled = true;
    }
  } catch (e) {
    setMsg("connect-msg", e.message, "err");
  } finally {
    done();
  }
}

function badge(kind) {
  const el = $("mode-badge");
  if (kind === "paper") { el.textContent = "paper / simulated"; el.className = "badge badge-paper"; }
  else if (kind === "live") { el.textContent = "LIVE ACCOUNT"; el.className = "badge badge-live"; }
  else { el.textContent = "not connected"; el.className = "badge badge-idle"; }
}

/* ---------- step 2: account ---------- */
async function refreshPositions() {
  const done = busy($("btn-refresh"), "Reading");
  setMsg("account-msg", "");
  try {
    const d = await api("/api/snapshot", { account_id: $("account-select").value });
    const rows = d.positions.map(p => `<tr>
        <td class="sym">${esc(p.symbol)}</td>
        <td class="r">${p.quantity.toLocaleString()}</td>
        <td class="r">${money(p.price)}</td>
        <td class="r">${money(p.market_value)}</td></tr>`).join("");
    $("positions").innerHTML =
      `<thead><tr><th>Symbol</th><th class="r">Qty</th><th class="r">Price</th>
       <th class="r">Value</th></tr></thead><tbody>${rows ||
       '<tr><td colspan="4" class="empty">no open positions</td></tr>'}</tbody>`;
    $("account-totals").innerHTML =
      `Positions ${money(d.positions_value)} &middot; Cash ${money(d.cash)}
       &middot; <strong>Total ${money(d.total_value)}</strong>`;
    $("positions-wrap").hidden = false;
    setMsg("account-msg",
           `${d.positions.length} position(s) read`, "ok");
  } catch (e) {
    setMsg("account-msg", e.message, "err");
  } finally {
    done();
  }
}

async function testConnection() {
  const done = busy($("btn-debug"), "Testing");
  $("debug-wrap").hidden = false;
  $("debug-wrap").open = true;
  $("debug-out").textContent = "waiting for the broker\u2026";
  setMsg("account-msg", "");
  try {
    const d = await api("/api/debug", { account_id: $("account-select").value });
    $("debug-out").textContent = JSON.stringify(d.raw, null, 2);
    setMsg("account-msg", "Raw response received", "ok");
  } catch (e) {
    $("debug-out").textContent = "Error: " + e.message;
    setMsg("account-msg", e.message, "err");
  } finally {
    done();
  }
}

/* ---------- step 3: target allocation ---------- */
async function showAllocation(okMsg = "") {
  const text = allocText();
  if (!text) { $("alloc-wrap").hidden = true; return; }
  const done = busy($("btn-parse"), "Reading");
  try {
    const d = await api("/api/parse-allocations", { text });
    $("alloc-table").innerHTML =
      `<thead><tr><th>Symbol</th><th>Holding</th><th class="r">Weight</th>
        <th class="r">Price</th></tr></thead><tbody>` +
      d.rows.map(r => `<tr>
          <td class="sym">${esc(r.symbol)}</td>
          <td class="name">${esc(r.holding)}</td>
          <td class="r">${(r.weight * 100).toFixed(1)}%</td>
          <td class="r">${r.price ? money(r.price) : "\u2014"}</td>
        </tr>`).join("") + "</tbody>";
    const pct = d.total_weight * 100;
    const off = Math.abs(pct - 100) > 1.5;
    $("alloc-totals").innerHTML =
      `${d.n} holding(s) &middot; weights total
       <strong class="${off ? "sell" : ""}">${pct.toFixed(1)}%</strong>` +
      (off ? " &mdash; that is a long way from 100%, check the file" : "");
    $("alloc-wrap").hidden = false;
    setMsg("alloc-msg", okMsg, okMsg ? "ok" : "");
  } catch (e) {
    $("alloc-wrap").hidden = true;
    setMsg("alloc-msg", e.message, "err");
  } finally {
    done();
  }
}

/* ---------- step 4: plan ---------- */
function allocText() {
  return $("alloc-text").value.trim();
}

async function computePlan() {
  const text = allocText();
  if (!text) { setMsg("plan-msg", "Load or paste a portfolio CSV first.", "err"); return; }
  const done = busy($("btn-plan"), "Computing");
  setMsg("plan-msg", "");
  const mode = document.querySelector('input[name="mode"]:checked').value;
  try {
    const d = await api("/api/plan", {
      account_id: $("account-select").value,
      allocations: text, mode,
      amount: parseFloat($("amount").value || "0"),
      pct: parseFloat($("pct").value || "99"),
    });
    S.planHash = d.plan_hash;
    S.paper = d.paper;
    renderPlan(d);
    setMsg("plan-msg",
           d.elapsed ? `Priced by the broker in ${d.elapsed}s` : "", "ok");
    $("step-plan").hidden = false;
    $("step-exec").hidden = false;
  } catch (e) {
    setMsg("plan-msg", e.message, "err");
  } finally {
    done();
  }
}

function renderPlan(d) {
  const rows = d.rows.filter(r => r.change !== 0 || r.target_shares !== 0);
  S.hasSells = d.rows.some(r => r.change < 0);
  S.hasBuys = d.rows.some(r => r.change > 0);
  S.sellsRun = false;

  $("warnings").innerHTML = (d.warnings || []).map(w =>
    `<p class="warn">${esc(w)}</p>`).join("");

  $("plan-table").innerHTML =
    `<thead><tr><th>Symbol</th><th class="r">Now</th><th class="r">Target</th>
      <th class="r">Change</th><th class="r">Price</th>
      <th class="r">Target value</th><th class="r">Weight</th><th></th></tr></thead>
     <tbody>` + rows.map(r => {
      const cls = r.change > 0 ? "buy" : r.change < 0 ? "sell" : "";
      const chg = r.change > 0 ? `+${r.change}` : r.change;
      return `<tr>
        <td class="sym">${esc(r.symbol)}</td>
        <td class="r">${r.current_shares.toLocaleString()}</td>
        <td class="r">${r.target_shares.toLocaleString()}</td>
        <td class="r ${cls}"><strong>${chg}</strong></td>
        <td class="r">${money(r.price)}</td>
        <td class="r">${money(r.target_value)}</td>
        <td class="r">${(r.target_weight * 100).toFixed(1)}%</td>
        <td class="note">${esc(r.note || "")}</td></tr>`;
    }).join("") + "</tbody>";

  const s = d.summary;
  $("plan-summary").innerHTML =
    `${s.n_sells} sell(s) ${money(s.sell_notional)} &middot;
     ${s.n_buys} buy(s) ${money(s.buy_notional)} &middot;
     net cash ${money(s.net_cash)}<br>
     Target book ${money(s.target_book)} of ${money(s.investable)} investable
     &middot; left uninvested ${money(s.uninvested)}`;

  $("sells-hint").textContent = S.hasSells
    ? `${d.rows.filter(r => r.change < 0).length} symbol(s) to sell.`
    : "Nothing to sell.";
  $("buys-hint").textContent = S.hasBuys
    ? `${d.rows.filter(r => r.change > 0).length} symbol(s) to buy.`
    : "Nothing to buy.";

  badge(S.paper ? "paper" : "live");
  syncExecControls();
}

/* ---------- step 5: execute ---------- */
/* Live orders are gated by a confirmation dialog rather than a typed phrase.
 * Returns the phrase the server still requires, or null if the person said no.
 * Dry runs and paper accounts skip the prompt entirely. */
function confirmOrders(what) {
  if ($("dry-run").checked || S.paper) return "";
  const ok = window.confirm(
    "Place REAL orders now?\n\n" + what + "\n\n" +
    "Account " + $("account-select").value + "\n" +
    "This cannot be undone from here.");
  return ok ? "PLACE ORDERS" : null;
}

function syncExecControls() {
  const dry = $("dry-run").checked;
  const live = !S.paper && !dry;
  $("live-warning").hidden = !live;

  // No typed phrase any more: each button asks at click time instead. The
  // SERVER still requires the phrase for live orders and confirmOrders()
  // supplies it only after the person says yes, so a stray API call still
  // cannot place anything.
  $("btn-sells").disabled = !S.hasSells;
  // The buy phase stays locked until sells have run, unless there are none
  // to run or we are only rehearsing.
  const sellsClear = !S.hasSells || S.sellsRun || dry;
  $("btn-buys").disabled = !S.hasBuys || !sellsClear;
  $("btn-confirm-sells").hidden = !(S.hasSells && !S.sellsRun && !dry);

  const tb = $("btn-topoff");
  if (tb) {
    tb.classList.toggle("is-dry", dry);
    tb.textContent = dry ? "Rehearse top off" : "Run top off";
  }

  for (const b of [$("btn-sells"), $("btn-buys")]) {
    b.classList.toggle("is-dry", dry);
    b.textContent = b.id === "btn-sells"
      ? (dry ? "Rehearse sell phase" : "Run sell phase")
      : (dry ? "Rehearse buy phase" : "Run buy phase");
  }
}

function logLine(html, kind = "") {
  const p = document.createElement("p");
  p.className = "logline " + kind;
  p.innerHTML = html;
  $("exec-log").appendChild(p);
  $("exec-log").scrollTop = $("exec-log").scrollHeight;
}

async function execute(phase) {
  const dry = $("dry-run").checked;
  const n = phase === "sells" ? S.hasSells : S.hasBuys;
  const phrase = confirmOrders(
    `${phase === "sells" ? "Sell" : "Buy"} phase \u2014 ${n} symbol(s).`);
  if (phrase === null) { logLine("Cancelled \u2014 nothing sent."); return; }
  const btn = phase === "sells" ? $("btn-sells") : $("btn-buys");
  const done = busy(btn, dry ? "Rehearsing" : "Placing orders");
  logLine(`<em>${dry ? "Rehearsing" : "Running"} ${phase}\u2026</em>`);
  try {
    const d = await api("/api/execute", {
      account_id: $("account-select").value,
      phase, order_type: $("order-type").value, dry_run: dry,
      plan_hash: S.planHash,
      confirm_phrase: phrase,
    });
    if (!d.results.length) logLine("nothing to do");
    for (const r of d.results) {
      // colour by side so the log reads the same way as the buttons;
      // failures stay red regardless of side
      const kind = !r.ok ? "err" : (r.action === "SELL" ? "sell" : "buy");
      logLine(`${r.ok ? "\u2713" : "\u2717"} <strong>${esc(r.action)}
        ${r.quantity} ${esc(r.symbol)}</strong> &mdash; ${esc(r.detail)}
        ${r.order_id ? `<span class="oid">#${esc(r.order_id)}</span>` : ""}`,
        kind);
    }
    if (!dry) {
      if (phase === "sells") S.sellsRun = true;
      watchFills(phase);
    }
  } catch (e) {
    logLine("Error: " + esc(e.message), "err");
  } finally {
    done();
  }
  syncExecControls();
}

async function runTopOff() {
  const dry = $("dry-run").checked;
  const reserve = parseFloat($("topoff-reserve").value);
  if (!(reserve >= 0)) { logLine("Reserve must be a number \u2265 0.", "err"); return; }
  const phrase = confirmOrders(
    `Top off \u2014 buy BIL with cash above $${reserve.toLocaleString()}.`);
  if (phrase === null) { logLine("Cancelled \u2014 nothing sent."); return; }
  const done = busy($("btn-topoff"), dry ? "Rehearsing" : "Placing order");
  logLine(`<em>${dry ? "Rehearsing" : "Running"} top off\u2026</em>`);
  try {
    const d = await api("/api/top-off", {
      account_id: $("account-select").value,
      reserve, order_type: $("order-type").value, dry_run: dry,
      confirm_phrase: phrase,
    });
    logLine(`cash ${money(d.cash)} &middot; reserve ${money(d.reserve)} ` +
            `&middot; ${esc(d.symbol)} @ ${money(d.price)}`);
    if (!d.results.length) {
      logLine(esc(d.detail || "nothing to do"), "warn");
    } else {
      for (const r of d.results) {
        logLine(`${r.ok ? "\u2713" : "\u2717"} <strong>BUY ${r.quantity} ` +
                `${esc(r.symbol)}</strong> &mdash; ${esc(r.detail)}` +
                `${r.order_id ? ` <span class="oid">#${esc(r.order_id)}</span>` : ""}`,
                r.ok ? "buy" : "err");
      }
      logLine(`leaves ${money(d.left)} in cash`);
      if (!dry) watchFills("topoff");
    }
  } catch (e) {
    logLine("Error: " + esc(e.message), "err");
  } finally { done(); }
}

/* ---------- fill watcher ----------------------------------------------
 * The old behaviour printed one line saying orders were still working and
 * never revisited it, so a completed batch looked identical to a stuck one.
 * Now: poll every POLL_MS until everything settles, print each fill as it
 * lands, and stop. Adapters with no order-status feed say so plainly and ask
 * the person to check with their broker, rather than showing a message that
 * cannot update.
 */
const POLL_MS = 5000;
const POLL_LIMIT_MS = 10 * 60 * 1000;      // give up after 10 minutes

function stopWatch() {
  if (S.pollTimer) { clearTimeout(S.pollTimer); S.pollTimer = null; }
  setMsg("exec-msg", "");
}

async function watchFills(phase) {
  if (S.pollTimer) { clearTimeout(S.pollTimer); S.pollTimer = null; }
  const started = Date.now();
  const seen = new Map();                  // symbol|action -> filled so far

  const tick = async () => {
    let d;
    try {
      d = await api("/api/order-status", { account_id: $("account-select").value });
    } catch (e) {
      logLine("Could not read order status: " + esc(e.message) +
              " \u2014 check fills with your broker.", "warn");
      setMsg("exec-msg", "");
      return;
    }
    if (!d.known) {
      logLine("This broker does not report order status \u2014 " +
              "check fills in your broker before continuing.", "warn");
      setMsg("exec-msg", "");
      return;
    }
    for (const o of d.orders) {
      const key = o.symbol + "|" + o.action;
      const prev = seen.get(key) || 0;
      if (o.filled > prev) {
        seen.set(key, o.filled);
        const px = o.avg_price ? ` @ ${o.avg_price.toFixed(2)}` : "";
        const part = o.filled < o.quantity
          ? ` (${o.filled}/${o.quantity} so far)` : "";
        logLine(`filled <strong>${esc(o.action)} ${o.filled} ` +
                `${esc(o.symbol)}</strong>${esc(px)}${esc(part)}`,
                o.action === "SELL" ? "sell" : "buy");
      }
    }
    if (d.settled) {
      logLine(phase === "sells"
        ? "All sells filled \u2014 safe to run the buys."
        : "All orders filled.", "ok");
      setMsg("exec-msg", "");
      syncExecControls();
      return;
    }
    if (Date.now() - started > POLL_LIMIT_MS) {
      logLine("Orders still working after 10 minutes \u2014 stopping the " +
              "watch; check with your broker.", "warn");
      setMsg("exec-msg", "");
      return;
    }
    const working = d.orders.filter(o => o.working).length;
    setMsg("exec-msg", `waiting on ${working} order(s)\u2026`, "warn");
    S.pollTimer = setTimeout(tick, POLL_MS);
  };
  tick();
}

/* ---------- TradeStation OAuth helper ---------- */
async function tsAuthUrl() {
  const cfg = readConfig();
  try {
    const d = await api("/api/ts/auth-url", {
      client_id: cfg.client_id, client_secret: cfg.client_secret,
      redirect_uri: $("ts-redirect").value,
    });
    window.open(d.url, "_blank");
    setMsg("ts-msg", "Sign in, approve, then paste the URL you land on.", "ok");
  } catch (e) { setMsg("ts-msg", e.message, "err"); }
}

async function tsExchange() {
  try {
    const d = await api("/api/ts/exchange", {
      redirect_response: $("ts-redirect-response").value,
    });
    $("f-refresh_token").value = d.refresh_token;
    setMsg("ts-msg", "Refresh token filled in above. Now press Connect.", "ok");
  } catch (e) { setMsg("ts-msg", e.message, "err"); }
}

/* ---------- wiring ---------- */
function init() {
  $("btn-connect").addEventListener("click", connect);
  $("btn-disconnect").addEventListener("click", async () => {
    stopWatch();
    await api("/api/disconnect", {});
    ["step-account", "step-alloc", "step-plan", "step-exec"].forEach(
      id => $(id).hidden = true);
    $("btn-disconnect").hidden = true;
    badge("idle");
    setMsg("connect-msg", "Disconnected.");
  });
  $("btn-refresh").addEventListener("click", refreshPositions);
  $("btn-debug").addEventListener("click", testConnection);
  $("btn-plan").addEventListener("click", computePlan);
  $("btn-sells").addEventListener("click", () => execute("sells"));
  $("btn-buys").addEventListener("click", () => execute("buys"));
  $("btn-topoff").addEventListener("click", runTopOff);
  $("btn-confirm-sells").addEventListener("click", async () => {
    await api("/api/confirm-sells", {});
    S.sellsRun = true;
    logLine("Sell completion confirmed manually.", "warn");
    syncExecControls();
  });
  $("btn-parse").addEventListener("click", showAllocation);
  $("alloc-text").addEventListener("change", showAllocation);
  $("btn-clear-log").addEventListener("click", () => {
    $("exec-log").innerHTML = "";
  });
  $("dry-run").addEventListener("change", syncExecControls);
  $("remember").addEventListener("change", e => {
    $("remember-secrets-wrap").hidden = !e.target.checked;
  });
  $("ts-open").addEventListener("click", tsAuthUrl);
  $("ts-exchange").addEventListener("click", tsExchange);

  $("alloc-file").addEventListener("change", ev => {
    const f = ev.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      $("alloc-text").value = rd.result;
      showAllocation(`Loaded ${f.name}`);
    };
    rd.onerror = () => setMsg("alloc-msg", "Could not read that file.", "err");
    rd.readAsText(f);
  });

  loadBrokers().catch(e => setMsg("connect-msg", e.message, "err"));
}

document.addEventListener("DOMContentLoaded", init);


/* ---------- theme toggle ----------------------------------------------
   The palette defaults to the OS preference (CSS media query, no attribute
   set). Ticking the box pins an explicit choice on <html data-theme> and
   stores it; the inline script in index.html re-applies it before first
   paint so there is no flash. */
(function initTheme() {
  const box = document.getElementById("dark-toggle");
  if (!box) return;
  const root = document.documentElement;
  const stored = (() => {
    try { return localStorage.getItem("balancer-theme"); } catch (e) { return null; }
  })();
  const osDark = window.matchMedia
    && window.matchMedia("(prefers-color-scheme: dark)").matches;
  box.checked = stored ? stored === "dark" : !!osDark;
  box.addEventListener("change", () => {
    const mode = box.checked ? "dark" : "light";
    root.setAttribute("data-theme", mode);
    try { localStorage.setItem("balancer-theme", mode); } catch (e) { /* ignore */ }
  });
})();
