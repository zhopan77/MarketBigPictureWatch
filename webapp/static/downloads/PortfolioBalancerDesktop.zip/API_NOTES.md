# TradeStation API — what is verified vs. inferred

Written while building the TradeStation adapter. Anything marked INFERRED has
NOT been confirmed against a live account and should be checked on first run
using the app's "Test connection" panel, which prints raw responses.

## VERIFIED against api.tradestation.com/docs

| Item | Value | Source |
|---|---|---|
| Live base URL | `https://api.tradestation.com/v3` | docs, rate-limiting page |
| Sim base URL  | `https://sim-api.tradestation.com/v3` | docs / community tooling |
| Authorize     | `GET https://signin.tradestation.com/authorize` | auth-code docs |
| Auth params   | `response_type=code, client_id, redirect_uri, audience=https://api.tradestation.com, state, scope` | auth-code docs |
| Scopes        | `openid offline_access profile MarketData ReadAccount Trade` | auth-code docs |
| Token         | `POST https://signin.tradestation.com/oauth/token`, form-encoded | auth-code docs |
| Refresh       | `grant_type=refresh_token, client_id, client_secret, refresh_token` | refresh-token docs |
| Token TTL     | `expires_in` = 1200 s (20 min) | auth-code docs |
| Accounts      | `GET /v3/brokerage/accounts` | docs, multiple wrappers |
| Positions     | `GET /v3/brokerage/accounts/{ids}/positions` | rate-limiting docs (explicit example) |
| Balances      | `GET /v3/brokerage/accounts/{ids}/balances` | ts-api endpoint table |
| Place order   | `POST /v3/orderexecution/orders` | two independent wrappers |
| Order body    | `{AccountID, Symbol, Quantity, OrderType, TradeAction, TimeInForce:{Duration}, Route}` | two independent wrappers |
| Order preview | `POST /v3/orderexecution/orderconfirm` (READ-ONLY) | MCP server implementation |
| Auth header   | `Authorization: Bearer <token>` | rate-limiting docs |
| Orders (read) | `GET /v3/brokerage/accounts/{ids}/orders` | ts-api endpoint table |

## INFERRED — verify on first run

| Item | Assumption | Mitigation in code |
|---|---|---|
| Quotes path | `GET /v3/marketdata/quotes/{comma,separated}` | falls back to `?symbols=` on 404, then to CSV prices |
| Positions JSON | `{"Positions":[{Symbol, Quantity, Last, MarketValue, LongShort}]}` | tolerant key lookup, several spellings tried |
| Balances JSON | `{"Balances":[{CashBalance, Equity, MarketValue}]}` | tolerant key lookup |
| Quote JSON | `{"Quotes":[{Symbol, Last, Close, PreviousClose}]}` | tolerant key lookup |
| Short positions | `LongShort == "Short"` implies negative quantity | applied if the field is present |
| Order status codes | `Status` is a short code (`ACK`/`FLL`/`FPR`), `StatusDescription` the human string | both normalised and checked; **unknown status counts as still working**, never as settled |
| Terminal statuses | FLL, FLP, CAN, REJ, EXP, BRO, DOA (+ their descriptions) | only unambiguous codes are listed; everything else stays "working" |
| Order response | `{"Orders":[{OrderID, Message}]}`, `Error` present on per-order rejection | tolerant lookup; a 200 carrying `Error` is treated as a failure |

## Verify these first, with real orders in SIMULATED mode

The order-status mapping above is the highest-risk inference left, because
`orders_settled()` is what the UI uses to say "safe to run the buys". Place a
resting limit order well away from the market in the Simulated environment,
open Test connection, and confirm the raw `Status` / `StatusDescription`
strings match the table. An unrecognised code is safe (it reads as working)
but will make the app poll until the 10-minute watch expires.

## Public.com and IB
Carried over unchanged from the user's working scripts, so they are already
proven against live accounts.
