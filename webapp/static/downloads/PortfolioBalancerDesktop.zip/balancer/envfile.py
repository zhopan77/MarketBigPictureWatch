"""
Optional .env loading, plus a "what can this process actually see" report.

WHY THIS EXISTS
    Environment variables are the documented way to prefill credentials, and
    on Windows they are also the single most common thing to get silently
    wrong. `setx` and System Properties only reach processes started AFTERWARDS;
    a `set` in one terminal is invisible to a double-clicked run.bat; and a
    variable exported in WSL or Git Bash is not in the Windows environment at
    all. In every one of those cases the app looks broken in exactly the same
    way -- an empty field and no explanation.

    So: read a .env file if one is there, and give the UI a way to say which
    variables it found rather than leaving the person to guess.

Deliberately dependency-free (no python-dotenv) so the desktop install stays
a plain `pip install -r requirements.txt`, and deliberately non-overriding: a
real environment variable always beats the file, because that is the one the
person set most recently and most explicitly.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Tuple

# Where a .env is looked for, in order. The first file found is loaded and the
# search stops -- two half-configured files is worse than one missing one.
#   1. $BALANCER_ENV_FILE  (explicit override, for odd installs)
#   2. the current working directory
#   3. next to the app itself, which is where run.bat launches from
#   4. the settings folder, so credentials can live with the other saved state
def _candidates() -> List[Path]:
    out = []
    override = os.environ.get("BALANCER_ENV_FILE")
    if override:
        out.append(Path(override).expanduser())
    out.append(Path.cwd() / ".env")
    out.append(Path(__file__).resolve().parent.parent / ".env")
    out.append(Path.home() / ".etf_balancer" / ".env")
    seen, uniq = set(), []
    for p in out:
        if str(p) not in seen:
            seen.add(str(p))
            uniq.append(p)
    return uniq


def _parse(text: str) -> Dict[str, str]:
    """KEY=VALUE per line. `export KEY=VALUE`, blank lines and #comments are
    tolerated; surrounding single or double quotes are stripped."""
    out: Dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.lower().startswith("export "):
            line = line[7:].lstrip()
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ("'", '"'):
            val = val[1:-1]
        if key:
            out[key] = val
    return out


# Filled in by load_env()/hydrate() so the UI can report what happened.
LOADED_FROM: str = ""
SEARCHED: List[str] = []
# varname -> where the value came from: "process" | "envfile" | "registry"
SOURCES: Dict[str, str] = {}


def read_windows_env() -> Dict[str, str]:
    """Windows only: the user's environment variables, read from the registry.

    A process inherits its environment ONCE, at creation. Anything added in
    System Properties afterwards is invisible to it for its whole life -- and
    to anything it launches. So an app started before the variable was created
    can never see it, no matter how many times the page is reloaded, and the
    person is left staring at a Control Panel dialog that plainly shows the
    value while the app insists it is not set.

    HKCU\\Environment *is* that dialog's "User variables" list, and the
    machine key is the "System variables" list below it. Reading them directly
    makes the app agree with what the person can see. HKCU wins over HKLM,
    matching how Windows itself resolves them.

    Read-only, stdlib-only, and a no-op everywhere but Windows.
    """
    if os.name != "nt":
        return {}
    try:
        import winreg
    except ImportError:                       # pragma: no cover
        return {}
    found: Dict[str, str] = {}
    keys = [(winreg.HKEY_CURRENT_USER, r"Environment"),
            (winreg.HKEY_LOCAL_MACHINE,
             r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")]
    for root, path in keys:
        try:
            with winreg.OpenKey(root, path) as k:
                i = 0
                while True:
                    try:
                        name, val, typ = winreg.EnumValue(k, i)
                    except OSError:
                        break
                    i += 1
                    if not isinstance(val, str):
                        continue
                    if typ == winreg.REG_EXPAND_SZ:
                        val = os.path.expandvars(val)
                    found.setdefault(name, val)   # HKCU set first -> HKCU wins
        except OSError:
            continue                          # key missing or not permitted
    return found


def hydrate(names: List[str]) -> None:
    """Fill any of `names` that this process is missing, from the registry.

    Deliberately scoped to the credential variables the adapters declare
    rather than importing the whole registry environment: PATH, PYTHONPATH and
    friends are already correct in this process, and rewriting them from a
    half-loaded registry copy mid-run is a good way to break something
    unrelated for no benefit.
    """
    missing = [n for n in names if not os.environ.get(n)]
    if not missing:
        return
    reg = read_windows_env()
    for n in missing:
        v = reg.get(n)
        if v:
            os.environ[n] = v
            SOURCES[n] = "registry"


def load_env() -> Tuple[str, List[str]]:
    """Load the first .env found. Never overrides a real environment variable.

    Returns (path_loaded_or_empty, paths_searched). Safe to call more than
    once; the second call is a no-op beyond refreshing the report.
    """
    global LOADED_FROM, SEARCHED
    SEARCHED = [str(p) for p in _candidates()]
    LOADED_FROM = ""
    for k in os.environ:
        SOURCES.setdefault(k, "process")
    for p in _candidates():
        try:
            if not p.is_file():
                continue
            for k, v in _parse(p.read_text(encoding="utf-8-sig")).items():
                if not os.environ.get(k):     # real env wins
                    os.environ[k] = v
                    SOURCES[k] = "envfile"
            LOADED_FROM = str(p)
            break
        except OSError:
            continue                          # unreadable file is not fatal
    return LOADED_FROM, SEARCHED


def _near_misses(name: str, pool: List[str]) -> List[str]:
    """Names in `pool` that a person would read as identical to `name`.

    The remaining way to have a variable that is plainly visible in the System
    Properties dialog and still unreadable by this app is for the NAME to be
    subtly wrong -- a trailing space, a non-breaking space pasted from a web
    page, or different case. All three render identically in that dialog. The
    value is never shown, only the name, with its whitespace made visible.
    """
    def squash(x: str) -> str:
        return "".join(ch for ch in x.lower() if ch.isalnum())
    target = squash(name)
    return [p for p in pool if p != name and squash(p) == target]


def env_report(names: List[str]) -> dict:
    """Which of `names` this process can see. Values are NEVER included -- only
    whether something is set and how long it is, which is enough to spot a
    variable that was set to an empty string or that picked up stray quotes."""
    # Everything this machine could plausibly offer, for near-miss matching.
    pool = list(os.environ.keys())
    try:
        pool += [k for k in read_windows_env() if k not in pool]
    except Exception:
        pass

    found = {}
    for n in names:
        v = os.environ.get(n)
        entry = {"set": v is not None and v != "",
                 "length": len(v) if v else 0,
                 # a variable present in the process but never seen by
                 # load_env() (set after import, or in a test) still came from
                 # the process -- report that rather than an empty string
                 "source": (SOURCES.get(n) or "process") if v else ""}
        if not entry["set"]:
            near = _near_misses(n, pool)
            if near:
                entry["similar"] = [repr(x) for x in near]
        found[n] = entry
    return {"vars": found, "env_file": LOADED_FROM, "searched": SEARCHED,
            "windows": os.name == "nt"}
