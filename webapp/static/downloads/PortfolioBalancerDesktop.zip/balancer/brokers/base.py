"""
The interface every broker adapter implements.

Adapters are deliberately thin: they translate one broker's API into the
neutral shapes in core.py and nothing more. All the rebalancing arithmetic
lives in core.py so it is identical whichever broker is selected.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..core import AccountSnapshot


@dataclass
class Field:
    """One credential/config input, rendered by the UI."""
    key: str
    label: str
    kind: str = "text"          # text | password | number | select | checkbox
    default: str = ""
    help: str = ""
    options: List[str] = field(default_factory=list)
    required: bool = True
    # Environment variable consulted for a default, so the same variables the
    # original command-line scripts used keep working.
    env: str = ""
    # Additional accepted names for the same value, tried in order after
    # `env`. Brokers acquire more than one convention over time (TradeStation
    # documents TRADESTATION_CLIENT_ID, but their portal hands you something
    # you naturally store as TS_API_KEY), and silently ignoring the variable
    # someone actually set is worse than checking two.
    env_alt: List[str] = field(default_factory=list)

    def env_names(self) -> List[str]:
        """Every variable this field accepts, most-preferred first."""
        return [n for n in [self.env, *self.env_alt] if n]


@dataclass
class OrderResult:
    symbol: str
    action: str                 # BUY | SELL
    quantity: int
    ok: bool
    detail: str = ""
    order_id: str = ""


class BrokerAdapter:
    """Base class. Adapters raise BrokerError with a human-readable message;
    the UI shows it verbatim, so the message is the error handling."""

    key: str = ""
    name: str = ""
    blurb: str = ""
    supports_limit: bool = True
    # Set when the adapter is talking to a paper/simulated venue, which the UI
    # uses to decide whether to show the live-trading warning.
    paper: bool = False

    @classmethod
    def config_fields(cls) -> List[Field]:
        raise NotImplementedError

    def connect(self, cfg: Dict[str, str]) -> None:
        raise NotImplementedError

    def disconnect(self) -> None:
        pass

    def list_accounts(self) -> List[str]:
        raise NotImplementedError

    def snapshot(self, account_id: str) -> AccountSnapshot:
        raise NotImplementedError

    def quotes(self, symbols: List[str], account_id: str) -> Dict[str, float]:
        raise NotImplementedError

    def snapshot_with_quotes(self, account_id: str, symbols: List[str]):
        """Positions plus prices covering held AND requested symbols.

        Building a plan needs both, and the naive route -- snapshot(), which
        internally quotes what is held, then quotes() over the union -- prices
        the overlap twice. For REST brokers that is a wasted HTTP call. For IB
        it is much worse: reqTickers waits for every symbol in the batch with
        no timeout, so a second batch roughly doubles the wall time.

        This default keeps the old two-call behaviour; adapters that can do it
        in one round trip override it.
        """
        snap = self.snapshot(account_id)
        syms = sorted(set(s.upper() for s in symbols)
                      | {p.symbol.upper() for p in snap.positions})
        return snap, (self.quotes(syms, account_id) or {})

    def place_order(self, account_id: str, symbol: str, action: str,
                    quantity: int, order_type: str,
                    limit_price: Optional[float] = None) -> OrderResult:
        raise NotImplementedError

    def orders_settled(self, account_id: str) -> bool:
        """True when nothing this adapter submitted is still working. Used to
        gate the buy phase behind the sell phase. Adapters that cannot tell
        return True and the UI asks the person to confirm manually."""
        return True

    def order_status(self, account_id: str) -> Optional[List[Dict[str, Any]]]:
        """Per-order fill state for orders this adapter submitted.

        Returns None when the adapter has no order-status feed -- the UI then
        tells the person to check fills in their broker rather than showing a
        message that can never update. Otherwise a list of dicts with
        symbol / action / quantity / filled / status.
        """
        return None

    def raw_debug(self, account_id: str) -> dict:
        """Raw API payloads, shown in the Test-connection panel so response
        shapes can be verified against a real account without a debugger."""
        return {}


class BrokerError(RuntimeError):
    pass
