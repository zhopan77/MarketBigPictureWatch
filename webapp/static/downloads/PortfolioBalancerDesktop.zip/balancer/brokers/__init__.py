"""Broker adapter registry.

Adapters are imported lazily inside get_adapter() so a missing optional
dependency (ib_insync, say) only breaks the broker that needs it rather than
preventing the app from starting at all.
"""

import os
from typing import Dict, List, Type

from .base import BrokerAdapter, BrokerError, Field, OrderResult

_REGISTRY = {
    "demo": (".demo", "DemoAdapter"),
    "ib": (".interactive_brokers", "IBAdapter"),
    "public": (".public_com", "PublicAdapter"),
    "tradestation": (".tradestation", "TradeStationAdapter"),
}


def adapter_class(key: str) -> Type[BrokerAdapter]:
    import importlib
    if key not in _REGISTRY:
        raise BrokerError(f"Unknown broker: {key}")
    mod_name, cls_name = _REGISTRY[key]
    mod = importlib.import_module(mod_name, __name__)
    return getattr(mod, cls_name)


def env_var_names() -> List[str]:
    """Every environment variable any adapter accepts, in declaration order."""
    names: List[str] = []
    for key in _REGISTRY:
        try:
            for f in adapter_class(key).config_fields():
                for n in f.env_names():
                    if n not in names:
                        names.append(n)
        except Exception:
            continue                      # unavailable adapter, skip its names
    return names


def list_brokers() -> List[dict]:
    # On Windows, pull any credential variable this process is missing out of
    # the registry FIRST -- otherwise a variable added in System Properties
    # after the app started can never be seen. Scoped to credential names
    # only; see envfile.hydrate().
    try:
        from ..envfile import hydrate
        hydrate(env_var_names())
    except Exception:
        pass                              # diagnostics must never block the UI
    out = []
    for key in _REGISTRY:
        try:
            cls = adapter_class(key)
            fields = []
            for f in cls.config_fields():
                d = dict(f.__dict__)
                # Prefill from the environment when one of the accepted
                # variables is set, leaving the field blank otherwise. The
                # variable that supplied the value is named in the help text,
                # so a surprising prefilled value is always explainable -- and
                # with aliases in play, "which one did it read?" is a question
                # someone will actually have.
                names = f.env_names()
                if names:
                    val, src = None, ""
                    for n in names:
                        v = os.environ.get(n)
                        if v:
                            val, src = v, n
                            break
                    if val:
                        d["default"] = val
                        d["from_env"] = src
                        d["help"] = (d.get("help", "") +
                                     f" Prefilled from ${src}.").strip()
                    else:
                        alts = "".join(f" or ${n}" for n in names[1:])
                        d["help"] = (d.get("help", "") +
                                     f" (set ${names[0]}{alts} to prefill)").strip()
                fields.append(d)
            out.append({
                "key": cls.key, "name": cls.name, "blurb": cls.blurb,
                "supports_limit": cls.supports_limit,
                "fields": fields,
                "available": True, "error": "",
            })
        except Exception as exc:      # dependency missing, etc.
            out.append({"key": key, "name": key, "blurb": "", "fields": [],
                        "supports_limit": False, "available": False,
                        "error": str(exc)})
    return out


__all__ = ["BrokerAdapter", "BrokerError", "Field", "OrderResult",
           "adapter_class", "list_brokers"]
