"""
Offline demo broker.

Not a real venue: it fabricates an account so the whole flow can be explored,
and the UI exercised, without credentials or a network connection. Orders are
accepted and discarded. It is always marked as paper, so the live-trading
warnings stay off.
"""

from __future__ import annotations

import random
from typing import Dict, List, Optional

from ..core import AccountSnapshot, Position
from .base import BrokerAdapter, Field, OrderResult

_PRICES = {
    "SPY": 738.93, "QQQ": 684.23, "IWM": 291.17, "EFA": 103.41,
    "EEM": 63.33, "TLT": 84.68, "IEF": 93.88, "GLD": 413.82,
    "XLE": 59.62, "BIL": 91.61, "VTI": 305.10,
}


class DemoAdapter(BrokerAdapter):
    key = "demo"
    name = "Demo (offline)"
    blurb = ("Fake account with made-up positions. No credentials, no network, "
             "no orders. Use it to try the workflow safely.")
    paper = True

    def __init__(self) -> None:
        self._seed = 7

    @classmethod
    def config_fields(cls) -> List[Field]:
        return [
            Field("cash", "Starting cash", "number", "25000", "", required=False),
        ]

    def connect(self, cfg: Dict[str, str]) -> None:
        self._cash = float(cfg.get("cash") or 25000)
        self.paper = True

    def list_accounts(self) -> List[str]:
        return ["DEMO-0001"]

    def snapshot(self, account_id: str) -> AccountSnapshot:
        rng = random.Random(self._seed)
        held = [("QQQ", 90), ("SPY", 14), ("VTI", 25), ("GLD", 8)]
        pos = []
        for sym, q in held:
            px = _PRICES[sym] * (1 + rng.uniform(-0.004, 0.004))
            pos.append(Position(sym, q, round(px, 2), round(q * px, 2)))
        return AccountSnapshot(account_id, pos, self._cash)

    def quotes(self, symbols: List[str], account_id: str = "") -> Dict[str, float]:
        rng = random.Random(self._seed + 1)
        return {s: round(_PRICES.get(s, 100.0) * (1 + rng.uniform(-0.004, 0.004)), 2)
                for s in symbols}

    def place_order(self, account_id, symbol, action, quantity, order_type,
                    limit_price: Optional[float] = None) -> OrderResult:
        return OrderResult(symbol, action, quantity, True,
                           f"demo fill ({order_type})", f"DEMO{abs(hash(symbol)) % 10000:04d}")

    def raw_debug(self, account_id: str) -> dict:
        return {"note": "demo adapter - values are fabricated",
                "prices": _PRICES}
