"""
Interactive Brokers, via the TWS/Gateway socket API (ib_insync).

Carried over from the user's working main_ib_tws.py, so the quote fallback
chain and the delayed-frozen data type are preserved verbatim -- those were
tuned against a real account and are easy to get subtly wrong.
"""

from __future__ import annotations

import asyncio
import math
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional

from ..core import AccountSnapshot, Position
from .base import BrokerAdapter, BrokerError, Field, OrderResult

# Ports differ by application AND by live/paper, which is the single easiest
# thing to get wrong here, so they are spelled out in the UI.
PORTS = {
    "TWS live (7496)": 7496,
    "TWS paper (7497)": 7497,
    "IB Gateway live (4001)": 4001,
    "IB Gateway paper (4002)": 4002,
}
PAPER_PORTS = {7497, 4002}

CONNECT_TIMEOUT = 8          # seconds per attempt
CLIENT_ID_RETRIES = 4        # base id, then base+1..+3


class _IBThread:
    """One dedicated thread owning one asyncio event loop, for ib_insync.

    ib_insync is asyncio-based and an IB object binds to the event loop of the
    thread that created it. FastAPI runs sync endpoints on a rotating pool of
    AnyIO worker threads, which breaks that in two ways:

      1. Those threads have no event loop at all, so the very first call dies
         with "There is no current event loop in thread 'AnyIO worker thread'".
      2. Even after installing a loop per call, the next request may land on a
         different worker thread, and the IB object would then be driving a
         loop that belongs to a thread that is not running it.

    Marshalling every IB call onto a single long-lived thread fixes both: the
    loop is created once, and connect/read/order all execute on the thread
    that owns it.
    """

    def __init__(self) -> None:
        self._ex = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ib-loop")
        self._ex.submit(self._install_loop).result()

    @staticmethod
    def _install_loop() -> None:
        asyncio.set_event_loop(asyncio.new_event_loop())

    def call(self, fn, *args, **kwargs):
        """Run fn on the IB thread and re-raise anything it throws here."""
        return self._ex.submit(fn, *args, **kwargs).result()

    def shutdown(self) -> None:
        # Close the loop on the thread that owns it; leaving it open leaks a
        # selector per connect/disconnect cycle.
        try:
            self._ex.submit(self._close_loop).result(timeout=5)
        except Exception:
            pass
        self._ex.shutdown(wait=False)

    @staticmethod
    def _close_loop() -> None:
        try:
            loop = asyncio.get_event_loop()
            if not loop.is_closed():
                loop.close()
        except Exception:
            pass


class IBAdapter(BrokerAdapter):
    key = "ib"
    name = "Interactive Brokers"
    blurb = ("Connects to TWS or IB Gateway running on this machine. Enable "
             "API access in Global Configuration \u2192 API \u2192 Settings.")

    def __init__(self) -> None:
        self.ib = None
        self._trades: list = []
        self._t: Optional[_IBThread] = None
        self.client_id: Optional[int] = None
        self._contracts: Dict[str, object] = {}     # symbol -> Stock contract

    @classmethod
    def config_fields(cls) -> List[Field]:
        return [
            Field("host", "Host", "text", "127.0.0.1",
                  "TWS/Gateway runs locally unless you changed it."),
            Field("port", "Connection", "select", "TWS live (7496)",
                  "Must match the socket port configured in TWS.",
                  options=list(PORTS.keys())),
            Field("client_id", "Client ID", "number", "10",
                  "Any integer not already used by another API client."),
        ]

    def connect(self, cfg: Dict[str, str]) -> None:
        # A fresh thread per connection, so a failed attempt cannot leave a
        # half-initialised loop behind.
        if self._t is not None:
            self._t.shutdown()
        self._t = _IBThread()
        self._t.call(self._connect_impl, cfg)

    def _connect_impl(self, cfg: Dict[str, str]) -> None:
        try:
            from ib_insync import IB, util
        except ImportError as exc:
            raise BrokerError(
                "ib_insync is not installed. Run: pip install ib_insync") from exc

        util.logToConsole("CRITICAL")
        host = cfg.get("host") or "127.0.0.1"
        port_label = cfg.get("port") or "TWS live (7496)"
        port = PORTS.get(port_label, 7496)
        self.paper = port in PAPER_PORTS
        base_cid = int(cfg.get("client_id") or 10)

        # ib_insync's connect is two awaits: open the socket, then wait for
        # TWS to start the API session. They fail for completely different
        # reasons and deserve completely different messages.
        #
        #   refused  -> nothing is listening; TWS down or wrong port
        #   timeout  -> socket opened but the API session never started,
        #               which is almost always this client ID still being
        #               registered from a previous connection. TWS releases
        #               it lazily, so an immediate reconnect on the same ID
        #               hangs. Stepping the ID gets straight back in.
        tried = []
        for offset in range(CLIENT_ID_RETRIES):
            cid = base_cid + offset
            tried.append(cid)
            ib = IB()
            try:
                ib.connect(host, port, clientId=cid, timeout=CONNECT_TIMEOUT)
                # Delayed-frozen once, here, instead of toggling it around
                # every quote call. It silently upgrades to live data when the
                # market is open and a subscription exists, and returns the
                # last known price when it is not.
                ib.reqMarketDataType(4)
                self.ib = ib
                self.client_id = cid
                self._contracts = {}
                return
            except ConnectionRefusedError:
                self._safe_disconnect(ib)
                raise BrokerError(
                    f"Nothing is listening on {host}:{port}. TWS or IB Gateway "
                    f"is not running, or its API socket is on a different port "
                    f"\u2014 check Global Configuration \u2192 API \u2192 Settings "
                    f"and make sure the port matches the Connection you picked.")
            except (asyncio.TimeoutError, TimeoutError):
                self._safe_disconnect(ib)
                continue
            except Exception as exc:
                self._safe_disconnect(ib)
                raise BrokerError(
                    f"Could not connect to IB at {host}:{port} "
                    f"({type(exc).__name__}: {exc})") from exc

        raise BrokerError(
            f"TWS is listening on {host}:{port} but never started an API "
            f"session, on client IDs {tried}. Usually one of:\n"
            f"  \u2022 a previous session still holds these IDs \u2014 wait a few "
            f"seconds, or set a different Client ID above;\n"
            f"  \u2022 TWS is showing an \u201cAccept incoming connection\u201d "
            f"prompt that needs clicking;\n"
            f"  \u2022 this machine is not in TWS's trusted-IP list.")

    @staticmethod
    def _safe_disconnect(ib) -> None:
        """Tear a half-open attempt down so it cannot hold the ID itself."""
        try:
            if ib is not None and ib.isConnected():
                ib.disconnect()
        except Exception:
            pass

    def disconnect(self) -> None:
        if self._t is not None:
            try:
                self._t.call(self._disconnect_impl)
            finally:
                self._t.shutdown()
                self._t = None
        self.ib = None

    def _disconnect_impl(self) -> None:
        if self.ib is not None and self.ib.isConnected():
            self.ib.disconnect()
            # Let the socket teardown reach TWS before the loop goes away,
            # so it can start releasing the client ID.
            try:
                self.ib.sleep(0.3)
            except Exception:
                pass
        self.ib = None

    def _require(self):
        if self.ib is None or not self.ib.isConnected():
            raise BrokerError("Not connected to IB.")
        return self.ib

    def _list_accounts_impl(self) -> List[str]:
        ib = self._require()
        accts = [a for a in ib.managedAccounts() if a != "All"]
        if not accts:
            raise BrokerError("No managed accounts returned by TWS.")
        return accts

    def quotes(self, symbols: List[str], account_id: str = "") -> Dict[str, float]:
        return self._marshal(self._quotes_impl, symbols, account_id)

    def _quotes_impl(self, symbols: List[str], account_id: str = "") -> Dict[str, float]:
        """Price lookup with the original's fallback chain.

        Market data type 4 (delayed frozen) returns the last known price when
        the market is closed, and silently upgrades to live when it is open --
        without it this returns NaN outside session hours.
        """
        ib = self._require()
        if not symbols:
            return {}
        from ib_insync import Stock

        # Reuse contract objects across calls; rebuilding them each time makes
        # TWS re-resolve the same SMART/USD stock over and over.
        contracts = []
        for sym in symbols:
            c = self._contracts.get(sym)
            if c is None:
                c = Stock(sym, "SMART", "USD")
                self._contracts[sym] = c
            contracts.append(c)

        tickers = ib.reqTickers(*contracts)

        out: Dict[str, float] = {}
        for sym, t in zip(symbols, tickers):
            px = t.marketPrice()
            for alt in (t.last, t.close, t.bid):
                if px is None or (isinstance(px, float) and math.isnan(px)) or px <= 0:
                    px = alt
                else:
                    break
            out[sym] = float(px) if px and not math.isnan(px) and px > 0 else 0.0
        return out

    def _snapshot_impl(self, account_id: str) -> AccountSnapshot:
        snap, _ = self._snapshot_with_quotes_impl(account_id, [])
        return snap

    def _snapshot_with_quotes_impl(self, account_id: str, symbols: List[str]):
        """Positions and prices in ONE quote batch.

        reqTickers blocks until every symbol in the batch has returned, so the
        cost is driven by the number of batches far more than by their size.
        Quoting the union of held and target symbols once is therefore close
        to twice as fast as quoting held symbols and then the union.
        """
        ib = self._require()
        raw = [p for p in ib.positions(account_id) if p.position != 0]

        wanted = {s.upper() for s in symbols}
        wanted |= {p.contract.symbol.upper() for p in raw}
        prices = self._quotes_impl(sorted(wanted)) if wanted else {}

        positions: List[Position] = []
        for p in raw:
            sym = p.contract.symbol
            qty = float(p.position)
            px = prices.get(sym.upper()) or float(p.avgCost)
            positions.append(Position(sym, qty, px, qty * px))

        cash = 0.0
        for cur in ("BASE", "USD"):
            for v in ib.accountValues(account_id):
                if v.tag == "TotalCashValue" and v.currency == cur:
                    cash = float(v.value)
                    break
            if cash:
                break
        return AccountSnapshot(account_id, positions, cash), prices

    def place_order(self, account_id: str, symbol: str, action: str,
                    quantity: int, order_type: str,
                    limit_price: Optional[float] = None) -> OrderResult:
        return self._marshal(self._place_order_impl, account_id, symbol, action,
                             quantity, order_type, limit_price)

    def _place_order_impl(self, account_id: str, symbol: str, action: str,
                          quantity: int, order_type: str,
                          limit_price: Optional[float] = None) -> OrderResult:
        ib = self._require()
        from ib_insync import LimitOrder, MarketOrder, Stock

        try:
            if order_type.upper() == "LMT":
                if not limit_price or limit_price <= 0:
                    raise BrokerError(f"{symbol}: limit order needs a price")
                order = LimitOrder(action, quantity, round(float(limit_price), 2))
            else:
                order = MarketOrder(action, quantity)
            order.account = account_id
            trade = ib.placeOrder(Stock(symbol, "SMART", "USD"), order)
            self._trades.append(trade)
            ib.sleep(0.4)
            status = trade.orderStatus.status if trade.orderStatus else "Submitted"
            return OrderResult(symbol, action, quantity, True, status,
                               str(getattr(trade.order, "orderId", "")))
        except Exception as exc:
            return OrderResult(symbol, action, quantity, False, str(exc))

    def _orders_settled_impl(self, account_id: str) -> bool:
        if self.ib is None:
            return True
        return not any(t.isActive() for t in self._trades)

    def _order_status_impl(self, account_id: str):
        """Fill state of every order submitted this session."""
        if self.ib is None:
            return None
        out = []
        for t in self._trades:
            st = t.orderStatus
            out.append({
                "symbol": t.contract.symbol,
                "action": str(t.order.action).upper(),
                "quantity": float(t.order.totalQuantity or 0),
                "filled": float(st.filled or 0),
                "avg_price": float(st.avgFillPrice or 0) or None,
                "status": str(st.status or ""),
                "working": bool(t.isActive()),
            })
        return out

    def _raw_debug_impl(self, account_id: str) -> dict:
        ib = self._require()
        return {
            "managedAccounts": list(ib.managedAccounts()),
            "positions": [
                {"symbol": p.contract.symbol, "position": float(p.position),
                 "avgCost": float(p.avgCost)}
                for p in ib.positions(account_id)
            ],
            "accountValues(TotalCashValue)": [
                {"tag": v.tag, "value": v.value, "currency": v.currency}
                for v in ib.accountValues(account_id) if v.tag == "TotalCashValue"
            ],
        }

    # ---- marshalling ----
    def _marshal(self, fn, *args, **kwargs):
        if self._t is None:
            raise BrokerError("Not connected to IB.")
        return self._t.call(fn, *args, **kwargs)

    def list_accounts(self) -> List[str]:
        return self._marshal(self._list_accounts_impl)

    def snapshot(self, account_id: str) -> AccountSnapshot:
        return self._marshal(self._snapshot_impl, account_id)

    def orders_settled(self, account_id: str) -> bool:
        return self._marshal(self._orders_settled_impl, account_id)

    def order_status(self, account_id: str):
        return self._marshal(self._order_status_impl, account_id)

    def raw_debug(self, account_id: str) -> dict:
        return self._marshal(self._raw_debug_impl, account_id)

    def snapshot_with_quotes(self, account_id: str, symbols: List[str]):
        return self._marshal(self._snapshot_with_quotes_impl, account_id, symbols)
