"""
TradeStation, via WebAPI v3.

Endpoints and the OAuth flow are transcribed from api.tradestation.com/docs;
see API_NOTES.md at the project root for exactly which parts are quoted from
the documentation and which are inferred from community wrappers.

Where a JSON shape is inferred, parsing is deliberately tolerant: several key
spellings are tried and the raw payload is available from the Test-connection
panel so it can be checked against a real account in seconds.

Auth model: the app holds a long-lived REFRESH token and mints short-lived
access tokens (they expire in 20 minutes). The refresh token can be obtained
from the "Get a refresh token" helper, which runs the documented
authorization-code flow against a throwaway localhost listener.
"""

from __future__ import annotations

import time
import urllib.parse
from typing import Dict, List, Optional

import requests

from ..core import AccountSnapshot, Position
from .base import BrokerAdapter, BrokerError, Field, OrderResult

SIGNIN = "https://signin.tradestation.com"
LIVE_BASE = "https://api.tradestation.com/v3"
SIM_BASE = "https://sim-api.tradestation.com/v3"
AUDIENCE = "https://api.tradestation.com"
SCOPES = "openid offline_access profile MarketData ReadAccount Trade"
TIMEOUT = 20


def _first(d: dict, *keys, default=None):
    """Return the first present, non-null key. Guards the inferred shapes:
    TradeStation is inconsistent about casing across endpoints."""
    for k in keys:
        if isinstance(d, dict) and d.get(k) is not None:
            return d[k]
    return default


def _num(v, default=0.0) -> float:
    try:
        return float(str(v).replace(",", "").replace("$", ""))
    except (TypeError, ValueError):
        return default


def authorize_url(client_id: str, redirect_uri: str, state: str) -> str:
    """The documented authorization-code URL."""
    q = urllib.parse.urlencode({
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "audience": AUDIENCE,
        "state": state,
        "scope": SCOPES,
    })
    return f"{SIGNIN}/authorize?{q}"


def exchange_code(client_id: str, client_secret: str, code: str,
                  redirect_uri: str) -> dict:
    """Swap an authorization code for tokens (form-encoded, per the docs)."""
    data = {"grant_type": "authorization_code", "client_id": client_id,
            "code": code, "redirect_uri": redirect_uri}
    if client_secret:
        data["client_secret"] = client_secret
    r = requests.post(f"{SIGNIN}/oauth/token", data=data, timeout=TIMEOUT,
                      headers={"content-type": "application/x-www-form-urlencoded"})
    if not r.ok:
        raise BrokerError(f"Token exchange failed ({r.status_code}): {r.text[:300]}")
    return r.json()


class TradeStationAdapter(BrokerAdapter):
    key = "tradestation"
    name = "TradeStation"
    blurb = ("Uses TradeStation WebAPI v3. Needs an API key (client id/secret) "
             "from the developer portal plus a refresh token \u2014 use the "
             "\u201cGet a refresh token\u201d helper if you do not have one.")

    def __init__(self) -> None:
        self.client_id = ""
        self.client_secret = ""
        self.refresh_token = ""
        self.base = LIVE_BASE
        self._access = ""
        self._expires_at = 0.0
        # OrderIDs submitted by THIS session, and how many placements were
        # attempted. /brokerage/accounts/{id}/orders returns the whole
        # account's day, so without this filter an order the person placed in
        # the TradeStation platform would be reported here as one of ours --
        # and, worse, would hold "settled" at False forever.
        self._order_ids: List[str] = []
        self._submitted = 0

    @classmethod
    def config_fields(cls) -> List[Field]:
        return [
            # TS_API_KEY / TS_SECRET are listed FIRST because that is what
            # the developer portal's "API Key" and "Secret" are naturally
            # stored as; TRADESTATION_* stay accepted so existing setups keep
            # working. Note these two are the OAuth CLIENT id and secret --
            # they are not a refresh token and cannot be used to call the API
            # on their own, which is why the third field still has to be
            # filled once via the helper below.
            Field("client_id", "Client ID (API key)", "text", "",
                  "From the TradeStation developer portal.",
                  env="TS_API_KEY",
                  env_alt=["TRADESTATION_CLIENT_ID", "TS_CLIENT_ID"]),
            Field("client_secret", "Client secret", "password", "",
                  "Leave blank only if your key is a public PKCE client.",
                  required=False, env="TS_SECRET",
                  env_alt=["TRADESTATION_CLIENT_SECRET", "TS_CLIENT_SECRET"]),
            Field("refresh_token", "Refresh token", "password", "",
                  "Long-lived. Use the helper below to obtain one.",
                  env="TS_REFRESH_TOKEN",
                  env_alt=["TRADESTATION_REFRESH_TOKEN"]),
            Field("environment", "Environment", "select", "Simulated",
                  "Simulated uses sim-api.tradestation.com \u2014 start here.",
                  options=["Simulated", "Live"]),
        ]

    # ---- auth ----
    def _refresh_access(self) -> None:
        data = {"grant_type": "refresh_token", "client_id": self.client_id,
                "refresh_token": self.refresh_token}
        if self.client_secret:
            data["client_secret"] = self.client_secret
        try:
            r = requests.post(f"{SIGNIN}/oauth/token", data=data, timeout=TIMEOUT,
                              headers={"content-type":
                                       "application/x-www-form-urlencoded"})
        except Exception as exc:
            raise BrokerError(f"Could not reach TradeStation sign-in: {exc}") from exc
        if not r.ok:
            raise BrokerError(
                f"TradeStation refused the refresh token ({r.status_code}). "
                f"It may be revoked or belong to a different API key. "
                f"{r.text[:200]}")
        payload = r.json()
        self._access = payload.get("access_token", "")
        if not self._access:
            raise BrokerError("No access_token in the token response.")
        # documented TTL is 1200 s; refresh a minute early to avoid races
        self._expires_at = time.time() + float(payload.get("expires_in", 1200)) - 60
        # rotating-refresh-token keys hand back a new one each time
        if payload.get("refresh_token"):
            self.refresh_token = payload["refresh_token"]

    def _headers(self) -> Dict[str, str]:
        if not self._access or time.time() >= self._expires_at:
            self._refresh_access()
        return {"Authorization": f"Bearer {self._access}",
                "Accept": "application/json"}

    def connect(self, cfg: Dict[str, str]) -> None:
        self.client_id = (cfg.get("client_id") or "").strip()
        self.client_secret = (cfg.get("client_secret") or "").strip()
        self.refresh_token = (cfg.get("refresh_token") or "").strip()
        env = (cfg.get("environment") or "Simulated").strip()
        self.base = SIM_BASE if env.lower().startswith("sim") else LIVE_BASE
        self.paper = self.base == SIM_BASE
        if not self.client_id or not self.refresh_token:
            raise BrokerError("Client ID and refresh token are both required.")
        self._access, self._expires_at = "", 0.0
        # Per-INSTANCE and reset on every connect, so order tracking cannot
        # leak across sessions or accounts.
        self._order_ids = []
        self._submitted = 0
        self._refresh_access()        # fail fast on bad credentials

    def _get(self, path: str) -> dict:
        r = requests.get(f"{self.base}{path}", headers=self._headers(),
                         timeout=TIMEOUT)
        if r.status_code == 401:
            self._access = ""         # force one refresh, then retry once
            r = requests.get(f"{self.base}{path}", headers=self._headers(),
                             timeout=TIMEOUT)
        if not r.ok:
            raise BrokerError(f"GET {path} failed ({r.status_code}): {r.text[:300]}")
        return r.json()

    def list_accounts(self) -> List[str]:
        data = self._get("/brokerage/accounts")
        accounts = _first(data, "Accounts", "accounts", default=[]) or []
        ids = []
        for a in accounts:
            aid = _first(a, "AccountID", "AccountId", "accountID", "accountId")
            if aid:
                ids.append(str(aid))
        if not ids:
            raise BrokerError(
                "No accounts returned. Check the API key has the ReadAccount "
                "scope and that the environment (Live vs Simulated) matches "
                "the account.")
        return ids

    def snapshot(self, account_id: str) -> AccountSnapshot:
        pos_data = self._get(f"/brokerage/accounts/{account_id}/positions")
        raw = _first(pos_data, "Positions", "positions", default=[]) or []

        positions: List[Position] = []
        for p in raw:
            sym = _first(p, "Symbol", "symbol", default="")
            if not sym:
                continue
            qty = _num(_first(p, "Quantity", "quantity", default=0))
            # Short legs may be reported as a positive quantity plus a side
            # flag rather than a negative number.
            side = str(_first(p, "LongShort", "longShort", default="") or "")
            if side.lower().startswith("short") and qty > 0:
                qty = -qty
            px = _num(_first(p, "Last", "last", "LastPrice", "MarkToMarketPrice",
                             "AveragePrice", default=0))
            mv = _num(_first(p, "MarketValue", "marketValue", default=0))
            if not mv:
                mv = qty * px
            if not px and qty:
                px = mv / qty
            positions.append(Position(str(sym).upper(), qty, px, mv))

        cash = 0.0
        try:
            bal = self._get(f"/brokerage/accounts/{account_id}/balances")
            entries = _first(bal, "Balances", "balances", default=[]) or []
            if entries:
                b = entries[0]
                cash = _num(_first(b, "CashBalance", "cashBalance",
                                   "RealTimeCashBalance", default=0))
        except BrokerError:
            # A missing balance is not fatal: the person can type the
            # investable amount instead of using the auto value.
            cash = 0.0

        return AccountSnapshot(account_id, positions, cash)

    def quotes(self, symbols: List[str], account_id: str = "") -> Dict[str, float]:
        """Quote snapshots.

        The path form is the documented one; if a deployment answers 404 we
        retry the query-string form before giving up, because this is the one
        endpoint whose shape could not be confirmed from the official docs.
        """
        if not symbols:
            return {}
        joined = ",".join(symbols)
        attempts = [f"/marketdata/quotes/{urllib.parse.quote(joined)}",
                    f"/marketdata/quotes?symbols={urllib.parse.quote(joined)}"]
        data = None
        errors = []
        for path in attempts:
            try:
                data = self._get(path)
                break
            except BrokerError as exc:
                errors.append(str(exc))
        if data is None:
            raise BrokerError("Quote request failed. " + " | ".join(errors))

        rows = _first(data, "Quotes", "quotes", default=[]) or []
        out: Dict[str, float] = {}
        for q in rows:
            sym = str(_first(q, "Symbol", "symbol", default="")).upper()
            px = _num(_first(q, "Last", "last", "Close", "close",
                             "PreviousClose", "previousClose", default=0))
            if sym:
                out[sym] = px
        return out

    # ---- orders ----
    def _order_body(self, account_id: str, symbol: str, action: str,
                    quantity: int, order_type: str,
                    limit_price: Optional[float]) -> dict:
        body = {
            "AccountID": account_id,
            "Symbol": symbol,
            "Quantity": str(int(quantity)),
            "OrderType": "Limit" if order_type.upper() == "LMT" else "Market",
            "TradeAction": "BUY" if action.upper() == "BUY" else "SELL",
            "TimeInForce": {"Duration": "DAY"},
            "Route": "Intelligent",
        }
        if body["OrderType"] == "Limit":
            body["LimitPrice"] = f"{float(limit_price):.2f}"
        return body

    def preview_order(self, account_id: str, symbol: str, action: str,
                      quantity: int, order_type: str,
                      limit_price: Optional[float] = None) -> dict:
        """Read-only cost/validity preview. Places nothing."""
        body = self._order_body(account_id, symbol, action, quantity,
                                order_type, limit_price)
        h = self._headers(); h["Content-Type"] = "application/json"
        r = requests.post(f"{self.base}/orderexecution/orderconfirm",
                          headers=h, json=body, timeout=TIMEOUT)
        if not r.ok:
            raise BrokerError(f"Preview failed ({r.status_code}): {r.text[:300]}")
        return r.json()

    def place_order(self, account_id: str, symbol: str, action: str,
                    quantity: int, order_type: str,
                    limit_price: Optional[float] = None) -> OrderResult:
        body = self._order_body(account_id, symbol, action, quantity,
                                order_type, limit_price)
        try:
            h = self._headers(); h["Content-Type"] = "application/json"
            r = requests.post(f"{self.base}/orderexecution/orders",
                              headers=h, json=body, timeout=TIMEOUT)
            if not r.ok:
                return OrderResult(symbol, action, quantity, False,
                                   f"{r.status_code}: {r.text[:200]}")
            payload = r.json()
            orders = _first(payload, "Orders", "orders", default=[]) or []
            oid, msg = "", "submitted"
            if orders:
                oid = str(_first(orders[0], "OrderID", "OrderId", default=""))
                msg = str(_first(orders[0], "Message", "message", default="submitted"))
                # A 200 can still carry a per-order rejection.
                if _first(orders[0], "Error", "error"):
                    return OrderResult(symbol, action, quantity, False,
                                       str(_first(orders[0], "Error", "error")))
            self._submitted += 1
            if oid:
                self._order_ids.append(oid)
            return OrderResult(symbol, action, quantity, True, msg, oid)
        except Exception as exc:
            return OrderResult(symbol, action, quantity, False, str(exc))

    # ---- order status -------------------------------------------------
    # TradeStation reports BOTH a short code in `Status` ("FLL") and a human
    # string in `StatusDescription` ("Filled"). Which of the two is populated
    # varies, so both are normalised and either one matching is enough.
    #
    # The test is deliberately inverted: an order counts as WORKING unless it
    # is positively known to be finished. The previous version listed the
    # WORKING states as long words ("received", "open", ...) and compared them
    # against `Status`, which is a short code -- so nothing ever matched, every
    # live order read as not-working, and orders_settled() returned True while
    # sells were still open. That is the wrong way to fail: "settled" is what
    # tells the person it is safe to run the buys.
    #
    # Only codes whose meaning is unambiguous are listed. Anything unrecognised
    # is treated as still working, and the raw status is passed through to the
    # UI so an unexpected value is visible rather than silently reinterpreted.
    _TERMINAL = {
        "fll", "filled",
        "flp", "partialfillurout",     # remainder cancelled -> done
        "can", "canceled", "cancelled",
        "rej", "rejected",
        "exp", "expired",
        "bro", "broken",
        "doa", "dead",
    }

    @staticmethod
    def _norm(v) -> str:
        """Lowercase, strip every non-alphanumeric. Makes 'Partial Fill
        (UROut)', 'PARTIAL_FILL_UROUT' and 'flp' comparable."""
        return "".join(ch for ch in str(v or "").lower() if ch.isalnum())

    def _is_working(self, order: dict) -> bool:
        tokens = {self._norm(_first(order, "Status", "status", default="")),
                  self._norm(_first(order, "StatusDescription",
                                    "statusDescription", default=""))}
        tokens.discard("")
        if not tokens:
            return True                       # no status at all -> assume alive
        return not (tokens & self._TERMINAL)

    def _fetch_orders(self, account_id: str) -> Optional[List[dict]]:
        """Raw order rows for the account, filtered to what THIS session sent.

        Returns None when the filter cannot be applied -- orders were placed
        but no OrderID came back -- which the UI renders as "this broker did
        not report status, check fills yourself" rather than as "all done".
        """
        if not self._order_ids:
            return [] if self._submitted == 0 else None
        try:
            data = self._get(f"/brokerage/accounts/{account_id}/orders")
        except BrokerError:
            return None                       # cannot tell -> UI says so
        rows = _first(data, "Orders", "orders", default=[]) or []
        mine = set(self._order_ids)
        return [o for o in rows
                if str(_first(o, "OrderID", "OrderId", default="")) in mine]

    def order_status(self, account_id: str):
        rows = self._fetch_orders(account_id)
        if rows is None:
            return None
        out = []
        for o in rows:
            legs = _first(o, "Legs", "legs", default=[]) or [{}]
            leg = legs[0] if legs else {}
            qty = _first(leg, "QuantityOrdered", "Quantity", default=0)
            filled = _first(leg, "ExecQuantity", "QuantityFilled", default=0)
            out.append({
                "symbol": str(_first(leg, "Symbol", "symbol", default="")),
                "action": str(_first(leg, "BuyOrSell", "Action",
                                     default="")).upper(),
                "quantity": _num(qty),
                "filled": _num(filled),
                "avg_price": _num(_first(leg, "ExecutionPrice", default=0)) or None,
                "status": str(_first(o, "StatusDescription", "Status",
                                     default="")),
                "working": self._is_working(o),
            })
        return out

    def orders_settled(self, account_id: str) -> bool:
        """Derived from order_status() rather than fetching again, so the two
        can never disagree about what settled means -- and so one poll costs
        one HTTP call instead of two."""
        st = self.order_status(account_id)
        if st is None:
            return True          # cannot tell -> UI asks for manual confirmation
        return all(not o["working"] for o in st)

    def raw_debug(self, account_id: str) -> dict:
        out: dict = {}
        for label, path in [
                ("accounts", "/brokerage/accounts"),
                ("positions", f"/brokerage/accounts/{account_id}/positions"),
                ("balances", f"/brokerage/accounts/{account_id}/balances")]:
            try:
                out[label] = self._get(path)
            except BrokerError as exc:
                out[label] = {"error": str(exc)}
        return out
