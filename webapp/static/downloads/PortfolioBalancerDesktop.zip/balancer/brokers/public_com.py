"""
Public.com, via their REST API.

Endpoints and payload shapes are taken verbatim from the user's working
main_public.py, so they are already proven against a live account.
"""

from __future__ import annotations

import uuid
from typing import Dict, List, Optional

import requests

from ..core import AccountSnapshot, Position
from .base import BrokerAdapter, BrokerError, Field, OrderResult

BASE = "https://api.public.com"
TIMEOUT = 15


class PublicAdapter(BrokerAdapter):
    key = "public"
    name = "Public.com"
    blurb = ("Uses the Public.com REST API. Create a secret under Settings "
             "\u2192 API and paste it below; it is exchanged for a short-lived "
             "access token.")
    supports_limit = False       # this adapter places MARKET orders only

    def __init__(self) -> None:
        self.secret = ""
        self.account_id = ""
        self._token: Optional[str] = None

    @classmethod
    def config_fields(cls) -> List[Field]:
        return [
            Field("secret", "API secret", "password", "",
                  "From Public.com \u2192 Settings \u2192 API.",
                  env="PUBLIC_API_TOKEN"),
            Field("account_id", "Account ID", "text", "",
                  "Your Public account identifier.", required=False,
                  env="PUBLIC_ACCOUNT_ID"),
        ]

    # ---- auth ----
    def _access_token(self) -> str:
        if self._token:
            return self._token
        try:
            r = requests.post(
                f"{BASE}/userapiauthservice/personal/access-tokens",
                json={"secret": self.secret, "validityInMinutes": 60},
                timeout=TIMEOUT)
            r.raise_for_status()
            self._token = r.json()["accessToken"]
        except requests.HTTPError as exc:
            raise BrokerError(
                f"Public.com rejected the API secret ({exc}). Check it is "
                f"current and has trading permissions.") from exc
        except Exception as exc:
            raise BrokerError(f"Could not reach Public.com: {exc}") from exc
        return self._token

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self._access_token()}",
                "Accept": "application/json",
                "Content-Type": "application/json"}

    def connect(self, cfg: Dict[str, str]) -> None:
        self.secret = (cfg.get("secret") or "").strip()
        self.account_id = (cfg.get("account_id") or "").strip()
        if not self.secret:
            raise BrokerError("An API secret is required.")
        self._token = None
        # Per-INSTANCE, and reset on every connect. A class-level list would be
        # shared by every adapter instance and would carry orders across
        # sessions.
        self._orders: List[dict] = []
        self._access_token()          # fail fast if the secret is bad

    def list_accounts(self) -> List[str]:
        # Public's API is account-scoped rather than offering a directory, so
        # the id has to be supplied. Returning it keeps the UI uniform.
        if not self.account_id:
            raise BrokerError(
                "Public.com needs an explicit Account ID; enter it above.")
        return [self.account_id]

    def _portfolio(self, account_id: str) -> dict:
        url = f"{BASE}/userapigateway/trading/{account_id}/portfolio/v2"
        r = requests.get(url, headers=self._headers(), timeout=TIMEOUT)
        if r.status_code == 403:
            raise BrokerError(
                "403 from Public.com. The token may lack portfolio permission, "
                "the account ID may be wrong, or the secret may have expired.")
        r.raise_for_status()
        return r.json()

    def snapshot(self, account_id: str) -> AccountSnapshot:
        pf = self._portfolio(account_id)
        positions: List[Position] = []
        for p in pf.get("positions", []):
            sym = p["instrument"]["symbol"]
            qty = float(p["quantity"])
            mv = float(p["currentValue"])
            if p.get("lastPrice"):
                px = float(p["lastPrice"]["lastPrice"])
            else:
                px = mv / qty if qty else 0.0
            positions.append(Position(sym, qty, px, mv))

        # `equity` is a list of {type, value}; the original summed all of it
        # for the account total, so total - positions gives the cash leg.
        equity_total = sum(float(i["value"]) for i in pf.get("equity", [])
                           if i.get("value") is not None)
        cash = equity_total - sum(p.market_value for p in positions)
        return AccountSnapshot(account_id, positions, cash)

    def quotes(self, symbols: List[str], account_id: str) -> Dict[str, float]:
        if not symbols:
            return {}
        url = f"{BASE}/userapigateway/marketdata/{account_id}/quotes"
        body = {"instruments": [{"symbol": s, "type": "EQUITY"} for s in symbols]}
        r = requests.post(url, headers=self._headers(), json=body, timeout=TIMEOUT)
        r.raise_for_status()
        out: Dict[str, float] = {}
        for q in r.json().get("quotes", []):
            sym = q["instrument"]["symbol"]
            px = q.get("last") or q.get("closePrice") or q.get("previousClose") or 0.0
            out[sym] = float(px)
        return out

    def place_order(self, account_id: str, symbol: str, action: str,
                    quantity: int, order_type: str,
                    limit_price: Optional[float] = None) -> OrderResult:
        if quantity <= 0:
            return OrderResult(symbol, action, quantity, False, "quantity must be positive")
        order_id = str(uuid.uuid4())
        body = {
            "orderId": order_id,
            "instrument": {"type": "EQUITY", "symbol": symbol},
            "orderSide": action,
            "orderType": "MARKET",       # this adapter is market-only
            # `expiration` is an OBJECT, not a string. Sending "DAY" produced
            #   Cannot construct instance of ...OrderExpiration
            #   (although at least one Creator exists):
            #   no String-argument constructor/factory method
            # which is Jackson refusing to build the type from a bare string.
            "expiration": {"timeInForce": "DAY"},
            "quantity": str(quantity),
        }
        try:
            r = requests.post(f"{BASE}/userapigateway/trading/{account_id}/order",
                              headers=self._headers(), json=body, timeout=TIMEOUT)
            r.raise_for_status()
            oid = r.json().get("orderId", order_id)
            # Track it so order_status() can report fills. Placement is
            # asynchronous here -- the 200 confirms submission only.
            if not hasattr(self, "_orders"):
                self._orders = []
            self._orders.append({"id": oid, "symbol": symbol,
                                 "action": action, "quantity": quantity})
            return OrderResult(symbol, action, quantity, True, "submitted", oid)
        except requests.HTTPError as exc:
            detail = ""
            try:
                detail = exc.response.text[:200]
            except Exception:
                pass
            return OrderResult(symbol, action, quantity, False, f"{exc} {detail}")
        except Exception as exc:
            return OrderResult(symbol, action, quantity, False, str(exc))

    # Statuses that mean the order is done moving. Anything else -- NEW,
    # PARTIALLY_FILLED, PENDING_* -- is still working.
    _TERMINAL = {"FILLED", "CANCELLED", "QUEUED_CANCELLED", "REJECTED",
                 "EXPIRED", "REPLACED"}

    def _order_detail(self, account_id: str, order_id: str) -> Optional[dict]:
        """GET a single order. Returns None on 404: placement is asynchronous
        and the docs warn an order may not be indexed yet, which must read as
        'still working' rather than 'gone'."""
        try:
            r = requests.get(
                f"{BASE}/userapigateway/trading/{account_id}/order/{order_id}",
                headers=self._headers(), timeout=TIMEOUT)
            if r.status_code == 404:
                return None
            r.raise_for_status()
            return r.json()
        except Exception:
            return None

    def order_status(self, account_id: str):
        if not getattr(self, "_orders", None):
            return []
        out = []
        for o in self._orders:
            d = self._order_detail(account_id, o["id"]) or {}
            status = str(d.get("status", "")).upper()
            out.append({
                "symbol": str(d.get("instrument", {}).get("symbol") or o["symbol"]),
                "action": str(d.get("side") or o["action"]).upper(),
                "quantity": float(d.get("quantity") or o["quantity"] or 0),
                "filled": float(d.get("filledQuantity") or 0),
                "avg_price": float(d.get("averagePrice") or 0) or None,
                "status": status or "PENDING",
                # no status yet (404) counts as working, not settled
                "working": status not in self._TERMINAL,
            })
        return out

    def orders_settled(self, account_id: str) -> bool:
        st = self.order_status(account_id)
        return all(not o["working"] for o in st) if st else True

    def raw_debug(self, account_id: str) -> dict:
        return {"portfolio/v2": self._portfolio(account_id)}
