"""
Broker-agnostic rebalancing maths.

Deliberately free of any broker or UI code so it can be unit tested on its
own: everything here is pure functions over plain data. The behaviour is
carried over from the original main_ib_tws.py / main_public.py so the numbers
this app produces match the scripts they replace.
"""

from __future__ import annotations

import csv
import io
import math
import re
from dataclasses import dataclass, field, asdict
from typing import Dict, Iterable, List, Optional


# =====================================================================
# Data
# =====================================================================
@dataclass
class Position:
    symbol: str
    quantity: float
    price: float
    market_value: float

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class AccountSnapshot:
    """What a broker adapter reports about an account at a point in time."""
    account_id: str
    positions: List[Position] = field(default_factory=list)
    cash: float = 0.0

    @property
    def positions_value(self) -> float:
        return sum(p.market_value for p in self.positions)

    @property
    def total_value(self) -> float:
        return self.positions_value + self.cash


@dataclass
class TradeRow:
    symbol: str
    current_shares: int
    target_shares: int
    change: int              # + buy, - sell
    price: float
    target_value: float
    target_weight: float     # share of the planned book, 0..1
    note: str = ""


# =====================================================================
# Allocation CSV
# =====================================================================
class AllocationError(ValueError):
    pass


def parse_allocations(text: str) -> Dict[str, float]:
    """Parse an ETF/stock portfolio CSV into {symbol: weight}.

    Some exports start with a bare `""` line before the header, so rather than
    blindly skipping line 1 (which breaks the moment a file is saved without
    it) we scan for the row that actually contains the Symbol/Weight header.

    Weights arrive as strings like "5.0%" and come back as fractions.
    """
    rows = list(csv.reader(io.StringIO(text)))
    header_idx = None
    for i, row in enumerate(rows[:10]):
        cleaned = [c.strip().strip('"').lower() for c in row]
        if "symbol" in cleaned and "weight" in cleaned:
            header_idx = i
            break
    if header_idx is None:
        raise AllocationError(
            "Could not find a header row containing 'Symbol' and 'Weight'. "
            "Expected an ETF/stock portfolio CSV."
        )

    header = [c.strip().strip('"') for c in rows[header_idx]]
    try:
        i_sym = [h.lower() for h in header].index("symbol")
        i_wt = [h.lower() for h in header].index("weight")
    except ValueError as exc:                      # pragma: no cover
        raise AllocationError(str(exc)) from exc

    out: Dict[str, float] = {}
    for row in rows[header_idx + 1:]:
        if len(row) <= max(i_sym, i_wt):
            continue
        sym = row[i_sym].strip().strip('"').upper()
        wt = row[i_wt].strip().strip('"')
        # the trailing "Total Allocation" marker row has no percentage
        if not sym or "%" not in wt:
            continue
        try:
            out[sym] = float(wt.replace("%", "").replace(",", "")) / 100.0
        except ValueError:
            continue

    if not out:
        raise AllocationError("No rows with a percentage weight were found.")

    total = sum(out.values())
    if not (0.90 <= total <= 1.10):
        raise AllocationError(
            f"Weights sum to {total*100:.1f}%, which is too far from 100% to "
            f"be a valid allocation. Check the file."
        )
    return out


def parse_allocation_rows(text: str) -> List[dict]:
    """Full rows from the allocation file, for display.

    Shares the header-detection of parse_allocations() rather than repeating
    it, so the table on screen can never disagree with the weights actually
    used to build the plan.
    """
    rows = list(csv.reader(io.StringIO(text)))
    header_idx = None
    for i, row in enumerate(rows[:10]):
        cleaned = [c.strip().strip('"').lower() for c in row]
        if "symbol" in cleaned and "weight" in cleaned:
            header_idx = i
            break
    if header_idx is None:
        raise AllocationError("No Symbol/Weight header row found.")

    header = [c.strip().strip('"').lower() for c in rows[header_idx]]
    idx = {name: header.index(name) for name in
           ("symbol", "holding", "weight", "amount", "price", "shares")
           if name in header}

    def cell(row, name):
        i = idx.get(name)
        if i is None or len(row) <= i:
            return ""
        return row[i].strip().strip('"')

    out: List[dict] = []
    for row in rows[header_idx + 1:]:
        sym = cell(row, "symbol").upper()
        wt = cell(row, "weight")
        if not sym or "%" not in wt:
            continue                     # skips the trailing marker row
        try:
            weight = float(wt.replace("%", "").replace(",", "")) / 100.0
        except ValueError:
            continue
        px_raw = cell(row, "price").replace("$", "").replace(",", "")
        try:
            price = float(px_raw)
        except ValueError:
            price = 0.0
        out.append({
            "symbol": sym,
            "holding": cell(row, "holding"),
            "weight": weight,
            "amount": cell(row, "amount"),
            "price": price,
            "shares": cell(row, "shares"),
        })
    if not out:
        raise AllocationError("No rows with a percentage weight were found.")
    return out


def parse_allocation_prices(text: str) -> Dict[str, float]:
    """Prices from the allocation file, used only as a last-resort fallback
    when a broker cannot quote a symbol."""
    rows = list(csv.reader(io.StringIO(text)))
    header_idx = next(
        (i for i, r in enumerate(rows[:10])
         if "symbol" in [c.strip().strip('"').lower() for c in r]), None)
    if header_idx is None:
        return {}
    header = [c.strip().strip('"').lower() for c in rows[header_idx]]
    if "price" not in header:
        return {}
    i_sym, i_px = header.index("symbol"), header.index("price")
    out: Dict[str, float] = {}
    for row in rows[header_idx + 1:]:
        if len(row) <= max(i_sym, i_px):
            continue
        sym = row[i_sym].strip().strip('"').upper()
        raw = row[i_px].strip().strip('"').replace("$", "").replace(",", "")
        try:
            px = float(raw)
        except ValueError:
            continue
        if sym and px > 0:
            out[sym] = px
    return out


# =====================================================================
# Planning
# =====================================================================
def compute_target_shares(investable: float,
                          weights: Dict[str, float],
                          prices: Dict[str, float]) -> Dict[str, int]:
    """Whole-share target for each symbol.

    Truncates rather than rounds, matching the original scripts: rounding up
    can ask for more cash than the account holds once every leg is summed.
    """
    total = sum(weights.values())
    if not (0.98 <= total <= 1.02):
        raise AllocationError(
            f"Target weights sum to {total:.4f}; expected ~1.0")

    out: Dict[str, int] = {}
    for sym, w in weights.items():
        px = prices.get(sym, 0.0)
        if px <= 0:
            raise AllocationError(f"No usable price for {sym}")
        out[sym] = int((investable * w) / px)
    return out


def build_plan(snapshot: AccountSnapshot,
               weights: Dict[str, float],
               prices: Dict[str, float],
               investable: float) -> List[TradeRow]:
    """Diff the account against the target and return one row per symbol.

    Symbols held but absent from the target get a zero target, i.e. they are
    sold down completely -- the same behaviour as the scripts this replaces.
    """
    targets = compute_target_shares(investable, weights, prices)
    current = {p.symbol.upper(): int(p.quantity) for p in snapshot.positions}
    held_prices = {p.symbol.upper(): p.price for p in snapshot.positions}

    rows: List[TradeRow] = []
    for sym in sorted(set(current) | set(targets)):
        tgt = targets.get(sym, 0)
        cur = current.get(sym, 0)
        px = prices.get(sym) or held_prices.get(sym, 0.0)
        note = ""
        if sym not in weights and cur != 0:
            note = "not in target - liquidating"
        rows.append(TradeRow(
            symbol=sym, current_shares=cur, target_shares=tgt,
            change=tgt - cur, price=px, target_value=tgt * px,
            target_weight=0.0, note=note,
        ))

    book = sum(r.target_value for r in rows)
    if book > 0:
        for r in rows:
            r.target_weight = r.target_value / book
    return rows


def plan_summary(rows: Iterable[TradeRow], snapshot: AccountSnapshot,
                 investable: float) -> dict:
    rows = list(rows)
    buys = [r for r in rows if r.change > 0]
    sells = [r for r in rows if r.change < 0]
    buy_notional = sum(r.change * r.price for r in buys)
    sell_notional = sum(-r.change * r.price for r in sells)
    target_book = sum(r.target_value for r in rows)
    return {
        "n_buys": len(buys),
        "n_sells": len(sells),
        "buy_notional": buy_notional,
        "sell_notional": sell_notional,
        "net_cash": sell_notional - buy_notional,
        "target_book": target_book,
        "investable": investable,
        "uninvested": investable - target_book,
        "account_total": snapshot.total_value,
        "cash": snapshot.cash,
        "positions_value": snapshot.positions_value,
    }


def preflight(rows: Iterable[TradeRow], snapshot: AccountSnapshot) -> List[str]:
    """Sanity checks worth surfacing BEFORE anything is sent to a broker.

    These are warnings, not hard blocks -- the person may have a good reason.
    But every one of them has a plausible bad cause, so they are shown."""
    rows = list(rows)
    warnings: List[str] = []

    for r in rows:
        if r.price <= 0:
            warnings.append(f"{r.symbol}: no price available; its target is unreliable.")
        if r.change < 0 and -r.change > r.current_shares:
            warnings.append(
                f"{r.symbol}: sell of {-r.change} exceeds the {r.current_shares} "
                f"held, which would open a short position.")

    buy_notional = sum(r.change * r.price for r in rows if r.change > 0)
    sell_notional = sum(-r.change * r.price for r in rows if r.change < 0)
    if buy_notional - sell_notional > snapshot.cash + 1e-6:
        warnings.append(
            f"Buys exceed sells by ${buy_notional - sell_notional:,.0f} but only "
            f"${snapshot.cash:,.0f} cash is available. Sells must settle first, "
            f"or some buys may be rejected.")

    if not any(r.change for r in rows):
        warnings.append("Nothing to do: the account already matches the target.")
    return warnings


def split_orders(rows: Iterable[TradeRow]) -> tuple[List[TradeRow], List[TradeRow]]:
    """Sells first, then buys. Selling first is what frees the cash the buys
    need, and is the ordering both original scripts used."""
    rows = [r for r in rows if r.change != 0]
    sells = sorted([r for r in rows if r.change < 0], key=lambda r: r.symbol)
    buys = sorted([r for r in rows if r.change > 0], key=lambda r: r.symbol)
    return sells, buys
