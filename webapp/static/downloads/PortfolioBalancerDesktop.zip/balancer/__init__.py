"""ETF/Stock Portfolio Balancer — desktop app."""
__version__ = "1.2.6"
