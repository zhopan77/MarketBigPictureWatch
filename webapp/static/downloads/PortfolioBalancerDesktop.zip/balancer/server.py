"""
Local HTTP backend for the desktop UI.

Binds to 127.0.0.1 only. Holds one broker session at a time, which is all a
single-user desktop app needs.

Order-safety design, since this can move real money:

  * Dry run is the DEFAULT and has to be switched off deliberately.
  * The plan is computed and shown before anything can be executed, and the
    exact plan that was shown is hashed; execution refuses to run against a
    plan that has changed underneath it.
  * Sells and buys are separate, explicitly confirmed phases, in that order.
  * Live (non-paper) execution additionally requires a typed confirmation
    phrase, so it cannot happen on a single stray click.
"""

from __future__ import annotations

import hashlib
import json
import os
import secrets
import stat
import threading
import time
import urllib.parse
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import core
from . import __version__
from .envfile import env_report, load_env
from .brokers import BrokerError, adapter_class, list_brokers

# Before ANY adapter reads os.environ. list_brokers() consults the environment
# on every /api/brokers call, so a .env loaded later would appear to work
# intermittently -- prefill on the second page load but not the first.
load_env()

WEB_DIR = Path(__file__).resolve().parent.parent / "web"
CONFIG_DIR = Path.home() / ".etf_balancer"
CONFIG_PATH = CONFIG_DIR / "settings.json"

app = FastAPI(title="ETF/Stock Portfolio Balancer", version=__version__)


# =====================================================================
# Session
# =====================================================================
class Session:
    def __init__(self) -> None:
        self.adapter = None
        self.broker_key = ""
        self.account_id = ""
        self.plan: List[core.TradeRow] = []
        self.plan_hash = ""
        self.snapshot: Optional[core.AccountSnapshot] = None
        self.sells_done = False
        self.lock = threading.Lock()

    def require(self):
        if self.adapter is None:
            raise HTTPException(400, "Not connected to a broker.")
        return self.adapter


S = Session()


def plan_fingerprint(rows: List[core.TradeRow], account_id: str) -> str:
    """Identifies the exact plan shown to the person. Execution checks this so
    a stale browser tab cannot submit a plan the account has moved past."""
    payload = json.dumps(
        [[r.symbol, r.change, round(r.price, 4)] for r in rows] + [account_id],
        sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


# =====================================================================
# Settings (local, opt-in for secrets)
# =====================================================================
def load_settings() -> dict:
    if CONFIG_PATH.is_file():
        try:
            return json.loads(CONFIG_PATH.read_text())
        except Exception:
            return {}
    return {}


def save_settings(data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2))
    try:                       # owner-only; secrets may be in here
        os.chmod(CONFIG_PATH, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


SECRET_KEYS = {"secret", "client_secret", "refresh_token", "token", "password"}


# =====================================================================
# Models
# =====================================================================
class ConnectReq(BaseModel):
    broker: str
    config: Dict[str, str] = {}
    remember: bool = False
    remember_secrets: bool = False


class PlanReq(BaseModel):
    account_id: str
    allocations: str
    mode: str = "auto"           # auto | manual
    amount: float = 0.0
    pct: float = 99.6


class ExecuteReq(BaseModel):
    account_id: str
    phase: str                   # sells | buys
    order_type: str = "MKT"      # MKT | LMT
    dry_run: bool = True
    plan_hash: str = ""
    confirm_phrase: str = ""


class TopOffReq(BaseModel):
    account_id: str
    symbol: str = "BIL"
    reserve: float = 200.0
    order_type: str = "MKT"
    dry_run: bool = True
    confirm_phrase: str = ""


class SettingsReq(BaseModel):
    data: dict


# =====================================================================
# Routes
# =====================================================================
@app.get("/api/env-check")
def api_env_check():
    """What the app process can actually see.

    The single most confusing failure here is a variable that is set in the
    person's terminal but not in the environment this process inherited --
    which on Windows is the normal outcome of `setx`, of System Properties
    while the app is already running, or of exporting it in WSL. The field
    help says "set $X to prefill" either way, so without this there is no way
    to tell "not set" from "set, but not here". Names and lengths only; values
    never leave the process.
    """
    names = []
    for b in list_brokers():
        for f in b.get("fields", []):
            for n in [f.get("env", "")] + list(f.get("env_alt") or []):
                if n and n not in names:
                    names.append(n)
    return env_report(names)


@app.get("/api/version")
def api_version():
    return {"version": __version__}


@app.get("/api/brokers")
def api_brokers():
    # `version` rides along so the UI can show what it is actually running
    # without a second round trip; a stale cached bundle reporting the old
    # number is exactly the confusion the no-store middleware exists to avoid.
    brokers = list_brokers()
    names = []
    for b in brokers:
        for f in b.get("fields", []):
            for n in [f.get("env", "")] + list(f.get("env_alt") or []):
                if n and n not in names:
                    names.append(n)
    return {"brokers": brokers, "saved": load_settings(),
            "version": __version__, "env": env_report(names)}


@app.post("/api/connect")
def api_connect(req: ConnectReq):
    with S.lock:
        if S.adapter is not None:
            try:
                S.adapter.disconnect()
            except Exception:
                pass
        try:
            cls = adapter_class(req.broker)
            adapter = cls()
            adapter.connect(req.config)
            accounts = adapter.list_accounts()
        except BrokerError as exc:
            raise HTTPException(400, str(exc))
        except Exception as exc:
            raise HTTPException(400, f"{type(exc).__name__}: {exc}")

        S.adapter, S.broker_key = adapter, req.broker
        S.plan, S.plan_hash, S.sells_done = [], "", False

        if req.remember:
            saved = load_settings()
            cfg = {k: v for k, v in req.config.items()
                   if req.remember_secrets or k not in SECRET_KEYS}
            saved[req.broker] = cfg
            saved["_last_broker"] = req.broker
            saved["_remember_secrets"] = req.remember_secrets
            save_settings(saved)

        return {"accounts": accounts,
                "paper": bool(getattr(adapter, "paper", False)),
                "supports_limit": cls.supports_limit,
                "client_id": getattr(adapter, "client_id", None)}


@app.post("/api/disconnect")
def api_disconnect():
    with S.lock:
        if S.adapter is not None:
            try:
                S.adapter.disconnect()
            except Exception:
                pass
        S.__init__()
    return {"ok": True}


@app.post("/api/snapshot")
def api_snapshot(body: Dict[str, str]):
    adapter = S.require()
    account_id = body.get("account_id", "")
    try:
        snap = adapter.snapshot(account_id)
    except BrokerError as exc:
        raise HTTPException(400, str(exc))
    S.snapshot, S.account_id = snap, account_id
    # Brokers return positions in whatever order their API feels like, which
    # makes the table hard to scan and shuffles between reads. Sort by symbol
    # so it matches the plan table, which core.build_plan already sorts.
    ordered = sorted(snap.positions, key=lambda p: p.symbol.upper())
    return {
        "positions": [p.as_dict() for p in ordered],
        "cash": snap.cash,
        "positions_value": snap.positions_value,
        "total_value": snap.total_value,
    }


@app.post("/api/parse-allocations")
def api_parse_allocations(body: Dict[str, str]):
    """Parse the allocation file for display.

    Goes through the same parser the plan uses, so the table on screen can
    never show something different from what the plan was built on.
    """
    text = body.get("text", "")
    try:
        rows = core.parse_allocation_rows(text)
    except core.AllocationError as exc:
        raise HTTPException(400, str(exc))
    total = sum(r["weight"] for r in rows)
    return {"rows": rows, "total_weight": total, "n": len(rows)}


@app.post("/api/plan")
def api_plan(req: PlanReq):
    adapter = S.require()
    try:
        weights = core.parse_allocations(req.allocations)
    except core.AllocationError as exc:
        raise HTTPException(400, str(exc))

    csv_prices = core.parse_allocation_prices(req.allocations)

    t0 = time.perf_counter()
    try:
        # One combined call: adapters that can price everything in a single
        # round trip do so (see BrokerAdapter.snapshot_with_quotes).
        snap, prices = adapter.snapshot_with_quotes(req.account_id, list(weights))
    except BrokerError as exc:
        raise HTTPException(400, str(exc))
    symbols = sorted(set(weights) | {p.symbol.upper() for p in snap.positions})
    elapsed = time.perf_counter() - t0

    # Fall back to the file's prices only where the broker could not quote,
    # and say so, because a stale price silently changes the share counts.
    stale: List[str] = []
    for sym in symbols:
        if not prices.get(sym):
            if csv_prices.get(sym):
                prices[sym] = csv_prices[sym]
                stale.append(sym)

    if req.mode == "manual":
        investable = float(req.amount)
    else:
        investable = snap.total_value * (float(req.pct) / 100.0)

    if investable <= 0:
        raise HTTPException(400, "Investable amount must be positive.")

    try:
        rows = core.build_plan(snap, weights, prices, investable)
    except core.AllocationError as exc:
        raise HTTPException(400, str(exc))

    warnings = core.preflight(rows, snap)
    if stale:
        warnings.append(
            "Using prices from the allocation file for " + ", ".join(stale) +
            " because the broker returned no quote. Share counts for those "
            "may be off if the file is not from today.")

    S.snapshot, S.account_id, S.plan = snap, req.account_id, rows
    S.plan_hash = plan_fingerprint(rows, req.account_id)
    S.sells_done = False

    return {
        "rows": [r.__dict__ for r in rows],
        "summary": core.plan_summary(rows, snap, investable),
        "warnings": warnings,
        "plan_hash": S.plan_hash,
        "paper": bool(getattr(adapter, "paper", False)),
        "elapsed": round(elapsed, 1),
    }


CONFIRM_PHRASE = "PLACE ORDERS"


@app.post("/api/execute")
def api_execute(req: ExecuteReq):
    adapter = S.require()
    with S.lock:
        if not S.plan:
            raise HTTPException(400, "No plan has been computed.")
        if req.plan_hash != S.plan_hash:
            raise HTTPException(
                409, "The plan changed since it was displayed. Recompute it "
                     "and review the new numbers before executing.")
        if req.account_id != S.account_id:
            raise HTTPException(400, "Account does not match the computed plan.")

        sells, buys = core.split_orders(S.plan)
        batch = sells if req.phase == "sells" else buys
        if req.phase not in ("sells", "buys"):
            raise HTTPException(400, "phase must be 'sells' or 'buys'")

        paper = bool(getattr(adapter, "paper", False))
        if not req.dry_run and not paper:
            if req.confirm_phrase.strip() != CONFIRM_PHRASE:
                raise HTTPException(
                    400, f"Live execution needs the confirmation phrase "
                         f"'{CONFIRM_PHRASE}'.")

        # Buying before the sells have settled is how an account ends up with
        # rejected orders, so the buy phase is gated behind the sell phase.
        if req.phase == "buys" and sells and not S.sells_done and not req.dry_run:
            raise HTTPException(
                409, "Run the sell phase first (or confirm it is complete).")

        results = []
        for r in batch:
            action = "SELL" if r.change < 0 else "BUY"
            qty = abs(r.change)
            if req.dry_run:
                results.append({
                    "symbol": r.symbol, "action": action, "quantity": qty,
                    "ok": True, "detail": "dry run - nothing sent",
                    "order_id": "",
                })
                continue
            res = adapter.place_order(
                req.account_id, r.symbol, action, qty, req.order_type,
                r.price if req.order_type.upper() == "LMT" else None)
            results.append(res.__dict__)

        if req.phase == "sells" and not req.dry_run:
            S.sells_done = True

        return {
            "phase": req.phase, "dry_run": req.dry_run, "results": results,
            "settled": adapter.orders_settled(req.account_id)
            if not req.dry_run else True,
        }


@app.post("/api/sells-settled")
def api_sells_settled(body: Dict[str, str]):
    """Ask the broker whether the sell batch has cleared; adapters that cannot
    tell return True and the UI makes the person confirm by hand."""
    adapter = S.require()
    try:
        settled = adapter.orders_settled(body.get("account_id", ""))
    except BrokerError as exc:
        raise HTTPException(400, str(exc))
    return {"settled": settled}


@app.post("/api/top-off")
def api_top_off(req: TopOffReq):
    """Sweep leftover cash into BIL, leaving `reserve` dollars behind.

    Deliberately BUY-ONLY and independent of the plan: it reads the account's
    cash fresh (after the sells and buys have settled, which is when the
    leftover is actually known) and sizes a single whole-share order. It never
    sells, so the worst case is that it does nothing.
    """
    adapter = S.require()
    if req.reserve < 0:
        raise HTTPException(400, "Reserve must be zero or positive.")
    paper = bool(getattr(adapter, "paper", False))
    if not req.dry_run and not paper:
        if req.confirm_phrase.strip() != CONFIRM_PHRASE:
            raise HTTPException(
                400, f"Live execution needs the confirmation phrase "
                     f"'{CONFIRM_PHRASE}'.")
    try:
        snap = adapter.snapshot(req.account_id)
        quotes = adapter.quotes([req.symbol], req.account_id)
    except BrokerError as exc:
        raise HTTPException(400, str(exc))

    price = float(quotes.get(req.symbol) or 0)
    if price <= 0:
        raise HTTPException(400, f"No usable quote for {req.symbol}.")
    investable = float(snap.cash) - float(req.reserve)
    qty = int(investable // price) if investable > 0 else 0

    info = {"cash": round(float(snap.cash), 2), "reserve": round(float(req.reserve), 2),
            "price": round(price, 4), "symbol": req.symbol, "quantity": qty,
            "cost": round(qty * price, 2),
            "left": round(float(snap.cash) - qty * price, 2)}
    if qty <= 0:
        return {**info, "results": [], "detail":
                f"Cash {snap.cash:,.2f} leaves nothing to invest above the "
                f"{req.reserve:,.2f} reserve."}
    if req.dry_run:
        return {**info, "results": [{
            "symbol": req.symbol, "action": "BUY", "quantity": qty,
            "ok": True, "detail": "dry run - nothing sent", "order_id": ""}]}
    res = adapter.place_order(req.account_id, req.symbol, "BUY", qty,
                              req.order_type,
                              price if req.order_type.upper() == "LMT" else None)
    return {**info, "results": [res.__dict__]}


@app.post("/api/order-status")
def api_order_status(body: Dict[str, str]):
    """Fill state of the orders submitted this session.

    `known` is False for adapters with no order-status feed (Public.com, demo).
    The UI uses it to decide between polling and telling the person to check
    fills in their broker -- rather than leaving a message up that can never
    change.
    """
    adapter = S.require()
    acct = body.get("account_id", "")
    try:
        orders = adapter.order_status(acct)
        settled = adapter.orders_settled(acct)
    except BrokerError as exc:
        raise HTTPException(400, str(exc))
    return {"known": orders is not None,
            "settled": bool(settled),
            "orders": orders or []}


@app.post("/api/confirm-sells")
def api_confirm_sells():
    """Manual override for brokers with no order-status feed."""
    S.sells_done = True
    return {"ok": True}


@app.post("/api/debug")
def api_debug(body: Dict[str, str]):
    adapter = S.require()
    try:
        return {"raw": adapter.raw_debug(body.get("account_id", ""))}
    except BrokerError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(400, f"{type(exc).__name__}: {exc}")


# ---- TradeStation OAuth helper -------------------------------------
_OAUTH: Dict[str, str] = {}


@app.post("/api/ts/auth-url")
def api_ts_auth_url(body: Dict[str, str]):
    """Build the authorization URL and arm a one-shot localhost listener.

    The redirect URI has to match one registered for the API key in the
    TradeStation developer portal, so it is an input rather than a constant.
    """
    from .brokers.tradestation import authorize_url

    client_id = (body.get("client_id") or "").strip()
    redirect = (body.get("redirect_uri") or "http://localhost:3000").strip()
    if not client_id:
        raise HTTPException(400, "Client ID is required.")
    parsed = urllib.parse.urlparse(redirect)
    if parsed.hostname not in ("localhost", "127.0.0.1"):
        raise HTTPException(
            400, "The redirect URI must point at localhost so this app can "
                 "catch the callback.")
    state = secrets.token_urlsafe(16)
    _OAUTH.clear()
    _OAUTH.update({"state": state, "redirect": redirect,
                   "client_id": client_id,
                   "client_secret": (body.get("client_secret") or "").strip(),
                   "port": str(parsed.port or 80)})
    return {"url": authorize_url(client_id, redirect, state), "state": state}


@app.post("/api/ts/exchange")
def api_ts_exchange(body: Dict[str, str]):
    """Swap the authorization code for a refresh token.

    The person pastes the full redirect URL they land on, which avoids
    needing a listener on a port the OS may not let us bind.
    """
    from .brokers.tradestation import exchange_code

    raw = (body.get("redirect_response") or "").strip()
    if not raw:
        raise HTTPException(400, "Paste the full URL you were redirected to.")
    # urlparse copes with every form a browser hands over, including the
    # scheme-less "localhost:3000/?code=..." the address bar DISPLAYS (it reads
    # "localhost" as the scheme, but the query still parses). The one case it
    # cannot handle is a paste of the parameters alone, with no "?" -- so fall
    # back to treating the whole string as the query.
    qs = urllib.parse.urlparse(raw).query
    if not qs and "=" in raw:
        qs = raw.lstrip("?")
    params = urllib.parse.parse_qs(qs)
    code = (params.get("code") or [""])[0]
    state = (params.get("state") or [""])[0]
    if not code:
        err = (params.get("error_description") or params.get("error") or [""])[0]
        raise HTTPException(400, f"No authorization code in that URL. {err}")
    if _OAUTH.get("state") and state and state != _OAUTH["state"]:
        raise HTTPException(400, "State mismatch; start the authorization again.")
    try:
        tok = exchange_code(_OAUTH.get("client_id", ""),
                            _OAUTH.get("client_secret", ""),
                            code, _OAUTH.get("redirect", ""))
    except BrokerError as exc:
        raise HTTPException(400, str(exc))
    if not tok.get("refresh_token"):
        raise HTTPException(
            400, "TradeStation returned no refresh token. The API key needs "
                 "the 'offline_access' scope.")
    return {"refresh_token": tok["refresh_token"],
            "scope": tok.get("scope", ""),
            "expires_in": tok.get("expires_in", "")}


@app.post("/api/settings")
def api_settings(req: SettingsReq):
    save_settings(req.data)
    return {"ok": True}


# ---- static UI ------------------------------------------------------
@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")


@app.middleware("http")
async def no_store(request, call_next):
    """Never let the webview cache the UI.

    StaticFiles sends no explicit Cache-Control, and WebView2 will happily
    reuse style.css and app.js from its own cache across app restarts -- so an
    upgraded build can render with the previous stylesheet and look like the
    change was lost. These files come off local disk, so there is nothing to
    gain from caching them.
    """
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
    return response


app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")
