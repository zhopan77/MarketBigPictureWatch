# ETF/Stock Portfolio Balancer — desktop app

Rebalances a brokerage account to an ETF/stock portfolio CSV.
Same arithmetic as the original `main_ib_tws.py` / `main_public.py` scripts,
wrapped in a UI, with **TradeStation** added alongside Interactive Brokers and
Public.com.

Runs on Windows, macOS and Linux from one Python install.

```
run.bat          (Windows)          creates .venv on first run, then launches
./run.sh         (macOS / Linux)
python app.py --browser             skip the native window

The launchers find Python themselves (py -3, then python, then python3), so
an Anaconda install with nothing on PATH is fine. If none of the three answer
they say so and stop.
```

## What it is

A local FastAPI server plus a native webview window (**pywebview**), which
uses whatever browser engine the OS already ships: WebView2 on Windows,
WKWebView on macOS, WebKitGTK on Linux. No Node, no Electron, no Rust
toolchain — the whole app is Python plus three static files, which is what
makes one codebase run on all three platforms. If the platform webview is
missing, it falls back to the default browser automatically.

Nothing is served off-machine: the server binds `127.0.0.1` on a random port
and the only outbound traffic is your broker's own API.

## The five steps

1. **Broker** — pick Demo, Interactive Brokers, Public.com or TradeStation.
   The credential fields change to match. Settings can be remembered;
   secrets only if you explicitly opt in.
2. **Account** — choose the account, read positions, and optionally dump the
   raw broker response for verification. Broker calls can take seconds, so
   every action that waits on one shows a spinner and an animated label
   ("Reading…", "Computing…", "Placing orders…") and disables itself until it
   returns. The restore runs in a `finally`, so a failed call cannot leave a
   button stuck.
3. **Target allocation** — load or paste the `Allocations.csv` export. It is
   shown as a table (symbol, holding, weight, price) with the weight total
   called out, so a bad file is visible before it reaches the plan. Then
   choose a percentage of account value or a fixed dollar amount.
4. **Plan** — a per-symbol diff: current, target, change, price, target value
   and weight, plus warnings.
5. **Execute** — sells first, then buys.

## Order safety

This moves real money, so the execution path is deliberately awkward:

- **Dry run is the default.** It prints exactly what would be sent and sends
  nothing. You have to turn it off on purpose.
- **The plan is fingerprinted.** Execution refuses to run against a plan that
  has changed since it was displayed, so a stale window cannot submit
  yesterday's trades.
- **Sides are colour-coded**: pink for sells, blue for buys, on both the
  phase buttons and the log (the log uses deeper variants, which read better
  as small text). Rejected orders stay red regardless of side. Rehearsing and
  armed look the same; what separates them is the button LABEL ("Rehearse …"
  vs "Run …"), the LIVE badge, and the typed confirmation phrase.
- **Sells and buys are separate phases**, sells first — that is what frees
  the cash the buys need. The buy phase stays locked until the sell phase has
  run (or you confirm by hand, for brokers with no order-status feed).
- **Live accounts need a typed phrase.** With dry run off on a non-paper
  venue, nothing is enabled until you type `PLACE ORDERS`. Paper and
  simulated venues skip this and are labelled as such in the header.
- **Preflight warnings** flag missing prices, sells that would open a short,
  and buys that exceed available cash.

Every guard is covered by a test that asserts *zero* orders reach the broker
when the guard trips.

## Brokers

| | Auth | Paper mode | Order types |
|---|---|---|---|
| Demo (offline) | none | always | market / limit (discarded) |
| Interactive Brokers | TWS/Gateway socket | port 7497 / 4002 | market, limit |
| Public.com | API secret | none | market only |
| TradeStation | OAuth refresh token | `sim-api` endpoint | market, limit |

**Interactive Brokers** runs all its calls on one dedicated thread that owns
one asyncio event loop. ib_insync is asyncio-based and an `IB` object binds to
the loop of the thread that created it, while FastAPI serves sync endpoints
from a rotating pool of AnyIO worker threads that have no loop at all — which
otherwise fails immediately with *"There is no current event loop in thread
'AnyIO worker thread'"*, and would still break later even if a loop were
installed per call, because the next request lands on a different thread.

**Speed.** Building a plan needs prices for both held and target symbols.
Fetching them as two batches (positions, then the union) is barely noticeable
over REST, but on IB it roughly doubles the wall time: `reqTickers` blocks
until *every* symbol in a batch has returned, with no timeout, so cost is
driven by the number of batches rather than their size. Adapters therefore
expose `snapshot_with_quotes()`, and the IB one prices the whole union in a
single batch — measured at a clean 2x, with identical prices and positions.
Contract objects are also cached per connection, and the market-data type is
set once at connect rather than toggled around every quote. The plan panel
reports how long the broker took.

**Reconnecting.** ib_insync's connect is two steps — open the socket, then
wait for TWS to start an API session — and they fail for entirely different
reasons. A refused socket means TWS is down or the port is wrong. A *timeout*
means the socket opened but the session never started, which is almost always
the client ID still being registered from the previous connection: TWS
releases IDs lazily, so an immediate reconnect on the same ID hangs. The
adapter now reports those two cases differently and, on a handshake timeout,
retries automatically on the next few client IDs. If it had to step past the
one you typed, the status line says so.

It also needs TWS or Gateway running locally with
*Enable ActiveX and Socket Clients* switched on, and the port in the app must
match the one configured there. Quotes use delayed-frozen market data so
prices still resolve outside session hours.

**Public.com** takes the API secret from Settings → API and exchanges it for a
short-lived token. Market orders only, matching the original script.

**Environment variables.** Credential fields prefill from the environment when
set, using the same names the original scripts used, and stay blank otherwise:

| Field | Variable |
|---|---|
| Public.com API secret | `PUBLIC_API_TOKEN` |
| Public.com account ID | `PUBLIC_ACCOUNT_ID` |
| TradeStation client ID | `TRADESTATION_CLIENT_ID` |
| TradeStation client secret | `TRADESTATION_CLIENT_SECRET` |
| TradeStation refresh token | `TRADESTATION_REFRESH_TOKEN` |

A prefilled field says so in its help text, so an unexpected value is always
explainable.

**TradeStation** needs a client id/secret from the developer portal plus a
refresh token. If you do not have one, the *Get a refresh token* panel runs
the documented authorization-code flow: it opens TradeStation sign-in, you
approve, then paste the URL you land on and it exchanges the code. Start in
**Simulated** — it is the default.

`API_NOTES.md` records exactly which TradeStation endpoints are quoted from
the official docs and which are inferred from community wrappers. The inferred
parts are parsed tolerantly and the **Test connection** button prints raw
responses, so you can confirm the shapes against your account in seconds.

## Verify before trusting it

The TradeStation adapter has **not** been run against a live account — I had
no credentials. Suggested first run:

1. Connect with Environment = **Simulated**.
2. Press **Test connection** and check `accounts`, `positions` and `balances`
   came back with the fields you expect.
3. Read positions and confirm the quantities match the TradeStation UI.
4. Compute a plan and leave **dry run on**. Check the share counts.
5. Only then turn dry run off, still on Simulated.

IB and Public.com carry over logic already proven against your live accounts,
but the same walkthrough is worth doing once.

## Layout

```
app.py                       entry point: server thread + webview window
balancer/
  core.py                    allocation parsing, target shares, diff, preflight
  server.py                  FastAPI routes, session state, execution guards
  brokers/
    base.py                  the adapter interface
    demo.py                  offline fake account
    interactive_brokers.py   ib_insync
    public_com.py            REST
    tradestation.py          WebAPI v3 + OAuth
web/                         index.html, app.js, style.css
API_NOTES.md                 verified vs. inferred TradeStation endpoints
```

All rebalancing arithmetic lives in `core.py` and is broker-agnostic, so the
numbers cannot drift between brokers. Adapters only translate one API into the
neutral shapes `core.py` uses.

## Packaging as a single executable (optional)

```
pip install pyinstaller
pyinstaller --noconfirm --windowed --name ETFBalancer \
  --add-data "web:web" app.py          # use "web;web" on Windows
```
Build on each target OS; PyInstaller does not cross-compile.


## Caching

The webview must not cache the UI. `StaticFiles` sends no explicit
`Cache-Control`, and WebView2 reuses `style.css` and `app.js` from its own
cache across app restarts -- so an upgraded build renders with the previous
stylesheet and the change looks lost. A middleware sends
`Cache-Control: no-store` for `/` and `/static/*`, and the links carry a
`?v=` query bumped each release so an already-cached copy is bypassed even
before that header is seen. These files come off local disk; there is nothing
to gain from caching them.

## Type scale

`html { font-size: 110% }` scales the whole UI. Nearly every size in the
stylesheet is in `rem`, and rem resolves against the ROOT element rather than
body -- raising `body { font-size }` alone would have moved only the few
elements that inherit their size, leaving every rem value untouched.

## v1.2.6

**The launcher was breaking pip and then hiding the evidence.** It ran
`pip install --upgrade pip` with output sent to nul. Upgrading pip means pip
uninstalling and reinstalling ITSELF, and an interruption -- antivirus, a
locked file, a dropped connection -- leaves it half replaced: a new `utils/`
directory under an old `__init__.py`. The next command then dies with
`ModuleNotFoundError: No module named
pip._internal.utils.inject_securetransport`, which describes the symptom and
not the cause, while the real failure went to nul.

The upgrade is gone. The pip that `venv` ships installs these dependencies
perfectly well, so it bought nothing and cost this.

**A broken venv now heals itself.** Pip is verified with `pip --version`
before use; if it cannot run, `ensurepip --upgrade` is tried, and if that is
not enough the venv is deleted and rebuilt. A folder already in the broken
state recovers on the next launch instead of needing manual deletion.
Verified end to end by corrupting a venv into exactly the reported state --
in a directory path containing both spaces and parentheses -- and watching it
detect, attempt repair, rebuild, and install cleanly.

Remaining pip output is no longer silenced, and a test asserts it stays that
way.

**Why it appeared to be about the folder name.** It was not the `(1)`. The
venv is only built on FIRST run, so the original folder -- which already had a
working `.venv` -- skipped every step involved. A freshly extracted copy has no
`.venv`, so it took the create-and-install path for the first time, and that is
where the fault always was.

## v1.2.5

**The launcher could not find Python on a machine that has Python.** `run.bat`
ran `python -m venv` directly. Anaconda does not put `python.exe` on the system
PATH -- that is what "Anaconda Prompt" exists for -- and the Microsoft Store
build installs an App Execution Alias that answers `python` with a Store page
rather than an interpreter. Either one produces
`'python' is not recognized`, followed by three `The system cannot find the
path specified` lines as the rest of the script runs against a venv that was
never created.

It only surfaced now because the venv is built on FIRST run: an existing
install has `.venv` already and never takes that path. Extracting a new release
into a clean folder does.

`run.bat` now probes `py -3` (the Windows launcher, installed by python.org and
independent of PATH order), then `python`, then `python3`; names all three if
none answer; and points at Anaconda Prompt specifically, since that is the most
likely cause. It then verifies `.venv\Scripts\python.exe` actually EXISTS
before using it, so a failed creation stops with one clear message instead of
cascading. Dependencies are installed only when an import check fails, so a
normal start no longer pays for a pip round trip.

`run.sh` gets the same treatment: `python3` then `python`, with a 3.9+ check.

## v1.2.4

**The environment note was reporting per-variable, and per-variable is the
wrong unit.** Each field accepts several alias names, so with `TS_API_KEY`
found it still listed `TRADESTATION_CLIENT_ID` and `TS_CLIENT_ID` as "not
visible to this app" -- in amber, as though something had failed, when only one
of the three is ever needed and one had worked.

It now reports per FIELD: satisfied if ANY of its names supplied a value. The
note appears only when NOT ONE env-backed field was filled, reads
"No environment variable found - please fill in manually.", and is plain grey
text. A partial result is normal and silent -- TradeStation's refresh token
comes from the helper, not the environment, so it is expected to be blank. The
near-miss clause survives, appended to that one line only when there is one.

**Redirect URI is explained rather than presented as a decision.** It is
required -- the same string is sent in the authorize URL and again in the token
exchange, and TradeStation rejects the pair unless it matches a URI registered
for the API key -- but the default is what almost every key uses. It is now a
compact row that says to leave it alone unless the portal registration differs.

**The two helper buttons use the standard button style** instead of `ghost`.

## v1.2.3

**The OAuth redirect landing on a dead port now reads as expected.** The flow
sends the browser to `http://localhost:3000/?code=...` and nothing listens
there by design -- the app never binds the port, it just needs the `code` out
of the address bar. Chrome renders that as *"This site can't be reached /
ERR_CONNECTION_REFUSED"*, which looks exactly like a failure, and the
explanation was a grey hint below the button that is easy to skip. It is now a
callout that names the error text verbatim and says what to do.

The paste parser also accepts the parameters on their own
(`code=...&state=...`, no `?`). Every other form already worked, including the
scheme-less `localhost:3000/?code=...` the address bar displays.

## v1.2.2

**The app now reads Windows environment variables from the registry.** v1.2.1
assumed a variable missing from `os.environ` was a variable the person had not
really set. Reported against a machine where `TS_API_KEY` and `TS_SECRET` were
plainly listed under User variables and the app was launched *after* they were
created -- so that assumption was simply wrong.

A process inherits its environment from its PARENT, not from the registry. If
the app is launched from an Explorer window, a terminal or an IDE that was
itself already open when the variable was added, it inherits that parent's
stale copy no matter how recently the app itself started. Explorer is supposed
to refresh on the `WM_SETTINGCHANGE` broadcast and often does not.

So the app stops relying on inheritance: on Windows it reads
`HKCU\Environment` and the machine-wide key directly -- those two keys *are*
the "User variables" and "System variables" lists in that dialog. Scoped to the
credential names the adapters declare, so `PATH` and `PYTHONPATH` are never
rewritten mid-run, and it never overrides a value already in the process.

**Near-miss names are called out.** The remaining way to have a variable that
is visible in the dialog and unreadable by the app is for the NAME to be
subtly wrong -- a trailing space, a non-breaking space pasted from a web page,
different case. All three render identically there. The diagnostic now reports
`'TS_API_KEY '` as a close match rather than flatly saying the variable is not
set. Names only; values still never leave the process.

The diagnostic also names where each value came from -- inherited, `.env` file,
or Windows user variables.

## v1.2.1

**Environment prefill did not fire, and the app could not say why.** Reported
against a machine where `TS_API_KEY` and `TS_SECRET` were set but every field
came up blank. The prefill code was fine -- the app's Python process simply
did not have those variables. That is the normal outcome of several ordinary
things on Windows: `setx` and System Properties only reach programs started
*afterwards*, a `set` in one terminal is invisible to a double-clicked
`run.bat`, and a variable exported in WSL or Git Bash is not in the Windows
environment at all. In every case the field help still read "set $TS_API_KEY
to prefill", which is indistinguishable from having set nothing.

Three changes:

- **`.env` support.** The first file found among `$BALANCER_ENV_FILE`, `./.env`,
  the folder holding `app.py`, and `~/.etf_balancer/.env` is loaded at startup.
  A real environment variable still wins -- this is a fallback, not an
  override. Dependency-free parser; see `.env.example`.
- **An environment diagnostic.** When a broker accepts credential variables and
  at least one is not visible to the process, an amber note under the fields
  lists which were found, which were not, which `.env` was loaded (or every
  path searched, if none), and what usually causes it. `GET /api/env-check`
  returns the same thing. Names and lengths only -- values never leave the
  process, so the note is safe to screenshot.
- **A remembered blank no longer pins a field empty.** The UI used
  `saved[key] ?? default`, and `??` only falls through on null/undefined. Ticking
  "Remember these settings" with a field blank stored `""`, which then beat the
  environment default on every later launch, with no way out short of deleting
  `settings.json`. Non-empty remembered values still win, as intended.

## v1.2

**TradeStation credentials load from the environment.** `TS_API_KEY` and
`TS_SECRET` prefill the Client ID and Client secret fields, the same way
`PUBLIC_API_TOKEN` already did for Public.com. `Field` now accepts alias
variable names, so the older `TRADESTATION_CLIENT_ID` /
`TRADESTATION_CLIENT_SECRET` keep working and the newer names win when both
are set. The field's help text names the variable it actually read, because
"why is this box already filled?" is otherwise unanswerable.

Note what this does NOT cover: `TS_API_KEY`/`TS_SECRET` are the OAuth *client*
id and secret. They cannot call the API on their own. The Refresh token field
still has to be filled once via the "Get a refresh token" helper (or by
setting `TS_REFRESH_TOKEN`).

**Order status was reading every live TradeStation order as finished.** The
adapter classified orders by testing `Status` against a list of long words
("received", "open", "queued"...). TradeStation puts a short code there —
`ACK`, `OPN`, `FPR` — and the human string in `StatusDescription`. Nothing ever
matched, so `working` was False for every open order and `orders_settled()`
returned True while sells were still live. That is the value the UI uses to
say "All sells filled — safe to run the buys".

Now both fields are normalised and checked, and the test is inverted: an order
counts as working unless it is *positively known* to be finished. An
unrecognised status reads as still working, which is the safe direction, and
the raw status is passed through to the UI so a surprising value is visible.

**Order status is scoped to this session.** `/brokerage/accounts/{id}/orders`
returns the account's whole day, so an order placed in the TradeStation
platform was being reported as one of the app's — and, being open, would hold
"settled" at False indefinitely. The adapter now records the OrderIDs it
submitted and filters to those. If orders were placed but no OrderID came back
it reports status as *unknown* rather than guessing, and the UI falls back to
asking the person to check fills themselves.

`orders_settled()` is now derived from `order_status()` instead of repeating
the fetch, so the two cannot disagree and one poll costs one HTTP call.

**Version is visible.** `balancer.__version__` is the single source; the server
serves it at `GET /api/version` and includes it in `/api/brokers`.

## v1.1## v1.1

* Phase 3: top off leftover cash into BIL above an editable reserve.
* Live orders confirm via a dialog instead of a typed phrase.
* Fill watching: polls order status and prints fills as they land.
* Public.com: fixed the order payload (`expiration` is an object) and added
  real order-status reporting.
* Larger type scale, dark-mode toggle, higher contrast.

## Phase 3 -- top off

Sweeps leftover cash into BIL, leaving a reserve (default $200, editable).
BUY-ONLY, and independent of the plan: it reads the account's cash FRESH at
click time, which is the only point the leftover is actually known -- after
the sells and buys have settled. Whole shares only, so it never overdraws.

    qty = floor((cash - reserve) / price)

If that is zero it says so and sends nothing. Because it never sells, the
worst case is that it does nothing.

## Confirming live orders

The typed `PLACE ORDERS` box is gone. With dry run off, each button asks for
confirmation at click time instead, naming the phase and the account.

The SERVER still requires the phrase for live orders. The browser supplies it
only after the person has confirmed, so the server-side guard still stops a
stray API call or a script mistake from placing anything -- the human gate
simply moved from a text box to a dialog.

## Fill watching

After a live phase the app polls `/api/order-status` every 5 seconds, printing
each fill as it lands and stopping when everything settles. It previously
printed one line saying orders were still working and never revisited it, so a
completed batch looked identical to a stuck one.

Adapters differ in what they can report, and the UI is explicit about it rather
than guessing:

| broker | order status |
|---|---|
| Interactive Brokers | yes -- `Trade.orderStatus` filled/avgFillPrice |
| TradeStation | yes -- `/brokerage/accounts/{id}/orders` |
| Public.com | yes -- `GET .../order/{orderId}` per submitted order |
| demo | no feed -- `known: false` |

Public.com placement is asynchronous and the docs warn an order may 404
briefly before it is indexed; that reads as "still working" rather than
"gone". When `known` is false the log says the broker does not report status and asks
the person to check fills themselves; the existing "I confirmed sells have
filled" button remains the way forward. The watch gives up after 10 minutes so
it cannot poll forever, and is cleared on disconnect.

## Theme

The palette follows the OS by default. The **Dark mode** checkbox in the
header pins an explicit choice on `<html data-theme>` and stores it in
`localStorage` under `balancer-theme`; clearing that key returns to following
the OS.

An inline script in `index.html` re-applies the stored choice before the body
paints -- without it a stored light preference flashes the dark palette while
`app.js` loads.

Text contrast was raised across both palettes (WCAG ratios against the panel
background): body text 13.4 -> 14.7 dark and 17.8 -> 19.2 light, and the
secondary/dim text that was the weak point 6.6 -> 8.7 and 6.0 -> 7.8. The buy,
sell and accent hues moved with them and all sit above AA.


## Public.com order payload

`expiration` is an OBJECT, not a string:

    "expiration": {"timeInForce": "DAY"}

Sending `"expiration": "DAY"` returns HTTP 400 with

    Cannot construct instance of ...OrderExpiration
    (although at least one Creator exists):
    no String-argument constructor/factory method

which is Jackson on their side refusing to build the type from a bare string.
Confirmed against the current place-order and get-order docs.
