@echo off
REM ---------------------------------------------------------------------
REM Windows launcher.
REM
REM FINDING PYTHON. This used to run `python` directly, which fails on a
REM machine that plainly HAS Python: Anaconda does not put python.exe on the
REM system PATH (that is what "Anaconda Prompt" is for), and the Microsoft
REM Store build installs an App Execution Alias that answers `python` with a
REM Store page instead of an interpreter. So: try the Windows launcher first
REM (py -3 -- installed by python.org, independent of PATH order), then
REM python, then python3.
REM
REM NOT UPGRADING PIP. There used to be a `pip install --upgrade pip` here,
REM with its output sent to nul. Upgrading pip means pip uninstalling and
REM reinstalling ITSELF, and when that is interrupted -- antivirus, a locked
REM file, a dropped connection -- it leaves a half-replaced package: a new
REM utils/ directory under an old __init__.py, which then dies with
REM "No module named pip._internal.utils.inject_securetransport" on the very
REM next command. Silencing it meant the actual failure was invisible and the
REM confusing one surfaced instead. The pip that `venv` creates installs these
REM dependencies perfectly well, so the upgrade bought nothing and cost this.
REM
REM SELF-HEALING. A venv whose pip cannot run is repaired with ensurepip, and
REM rebuilt from scratch if that is not enough -- so a folder already in this
REM broken state fixes itself on the next launch instead of needing manual
REM deletion.
REM ---------------------------------------------------------------------
setlocal
cd /d "%~dp0"

set "PY="
py -3 --version >nul 2>&1
if not errorlevel 1 ( set "PY=py -3" & goto :found )
python --version >nul 2>&1
if not errorlevel 1 ( set "PY=python" & goto :found )
python3 --version >nul 2>&1
if not errorlevel 1 ( set "PY=python3" & goto :found )

echo.
echo   Could not find Python. Tried: py -3, python, python3
echo.
echo   If you use Anaconda, open "Anaconda Prompt", cd to this folder and
echo   run run.bat from there - Anaconda does not add python to the system
echo   PATH, so a double-clicked .bat cannot see it.
echo.
echo   Otherwise install Python 3.9 or newer from
echo   https://www.python.org/downloads/ and tick
echo   "Add python.exe to PATH" in the installer.
echo.
pause
exit /b 1

:found
set "VPY=.venv\Scripts\python.exe"
if exist "%VPY%" goto :checkpip

echo Creating virtual environment using %PY% ...
%PY% -m venv .venv
REM Check the RESULT, not the exit code: carrying on against a venv that does
REM not exist is what produced three "cannot find the path specified" lines.
if not exist "%VPY%" goto :venvfail

:checkpip
"%VPY%" -m pip --version >nul 2>&1
if not errorlevel 1 goto :deps

echo Pip in the virtual environment is not usable - repairing ...
"%VPY%" -m ensurepip --upgrade
"%VPY%" -m pip --version >nul 2>&1
if not errorlevel 1 goto :deps

echo Repair did not take - rebuilding the virtual environment ...
rmdir /s /q .venv
%PY% -m venv .venv
if not exist "%VPY%" goto :venvfail
"%VPY%" -m pip --version >nul 2>&1
if errorlevel 1 goto :pipfail

:deps
REM Install only when something is missing, so a normal start is not delayed
REM by a dependency check every time.
"%VPY%" -c "import fastapi, uvicorn, requests" >nul 2>&1
if not errorlevel 1 goto :run

echo Installing dependencies ...
"%VPY%" -m pip install --disable-pip-version-check --no-warn-script-location -r requirements.txt
if errorlevel 1 goto :depsfail

:run
"%VPY%" app.py %*
pause
exit /b 0

:venvfail
echo.
echo   Failed to create the virtual environment in .venv
echo   Try running this by hand to see the reason:
echo       %PY% -m venv .venv
echo.
pause
exit /b 1

:pipfail
echo.
echo   The virtual environment was created but pip does not work in it.
echo   Delete the .venv folder and run this again. If it keeps happening,
echo   the Python being used may be the Microsoft Store build, which is
echo   more restricted - installing Python from python.org usually fixes it.
echo.
pause
exit /b 1

:depsfail
echo.
echo   Dependency install failed - see the messages above.
echo   Deleting the .venv folder and running this again clears most causes.
echo.
pause
exit /b 1
