"""
Tests for the parts that can be wrong quietly.

Run:  python -m pytest tests -q        (or: python tests/test_balancer.py)

The execution tests all assert the same thing in different ways: when a guard
trips, ZERO orders reach the broker. A stub adapter records every call, so a
guard that silently stopped working would show up as a non-empty list.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient

from balancer import core, server
from balancer.brokers.base import BrokerAdapter, OrderResult

ALLOC = '''""
"Symbol","Holding","Weight","Amount","Price","Shares"
"QQQ","Invesco QQQ Trust","60.0%","$60,000","$684.23","87"
"XLE","Energy Select SPDR","40.0%","$40,000","$59.62","671"
"Total Allocation","","(adjust leverage here)"
'''


# ---------- core ----------
def test_parse_allocations():
    w = core.parse_allocations(ALLOC)
    assert w == {"QQQ": 0.60, "XLE": 0.40}


def test_parse_tolerates_missing_leading_blank_line():
    w = core.parse_allocations(ALLOC.split("\n", 1)[1])
    assert w == {"QQQ": 0.60, "XLE": 0.40}


def test_parse_rejects_nonsense():
    for bad in ("", "a,b,c\n1,2,3"):
        try:
            core.parse_allocations(bad)
        except core.AllocationError:
            continue
        raise AssertionError("should have rejected: %r" % bad)


def test_target_shares_truncate_not_round():
    # 0.6 * 1000 / 684.23 = 0.877 -> 0, never 1: rounding up over-commits cash
    t = core.compute_target_shares(1000, {"QQQ": 0.6, "XLE": 0.4},
                                   {"QQQ": 684.23, "XLE": 59.62})
    assert t == {"QQQ": 0, "XLE": 6}


def test_untargeted_holdings_are_liquidated():
    snap = core.AccountSnapshot("A", [core.Position("VTI", 10, 300.0, 3000.0)], 0.0)
    rows = core.build_plan(snap, {"QQQ": 1.0}, {"QQQ": 100.0, "VTI": 300.0}, 1000)
    vti = next(r for r in rows if r.symbol == "VTI")
    assert vti.target_shares == 0 and vti.change == -10


def test_preflight_flags_overspend():
    snap = core.AccountSnapshot("A", [], cash=100.0)
    rows = core.build_plan(snap, {"QQQ": 1.0}, {"QQQ": 100.0}, 10_000)
    assert any("exceed" in w for w in core.preflight(rows, snap))


def test_sells_are_ordered_before_buys():
    rows = [core.TradeRow("AAA", 0, 5, 5, 10, 50, 0.5),
            core.TradeRow("BBB", 5, 0, -5, 10, 0, 0.0)]
    sells, buys = core.split_orders(rows)
    assert [r.symbol for r in sells] == ["BBB"]
    assert [r.symbol for r in buys] == ["AAA"]


# ---------- execution guards ----------
class Stub(BrokerAdapter):
    key, name, paper = "stub", "Stub", False

    def __init__(self):
        self.sent = []

    def list_accounts(self):
        return ["A1"]

    def snapshot(self, a):
        # VTI is deliberately NOT in the target, so every plan built from this
        # stub contains at least one sell and the buy-gating guard is live.
        return core.AccountSnapshot(a, [
            core.Position("QQQ", 1, 684.23, 684.23),
            core.Position("VTI", 10, 300.0, 3000.0),
        ], 50_000.0)

    def quotes(self, syms, a=""):
        return {"QQQ": 684.23, "XLE": 59.62, "VTI": 300.0}

    def place_order(self, a, sym, act, qty, ot, lp=None):
        self.sent.append((act, sym, qty))
        return OrderResult(sym, act, qty, True, "ok", "1")

    def orders_settled(self, a):
        return True


def _session():
    stub = Stub()
    server.S.__init__()
    server.S.adapter = stub
    c = TestClient(server.app)
    plan = c.post("/api/plan", json={"account_id": "A1", "allocations": ALLOC,
                                     "mode": "manual", "amount": 50_000}).json()
    return c, stub, plan["plan_hash"]


def test_guard_stale_plan_hash():
    c, stub, _ = _session()
    r = c.post("/api/execute", json={"account_id": "A1", "phase": "buys",
                                     "dry_run": False, "plan_hash": "stale",
                                     "confirm_phrase": "PLACE ORDERS"})
    assert r.status_code == 409 and stub.sent == []


def test_guard_live_requires_phrase():
    c, stub, h = _session()
    r = c.post("/api/execute", json={"account_id": "A1", "phase": "sells",
                                     "dry_run": False, "plan_hash": h})
    assert r.status_code == 400 and stub.sent == []


def test_guard_buys_locked_until_sells_run():
    c, stub, h = _session()
    assert any(r.change < 0 for r in server.S.plan), "fixture must contain a sell"
    r = c.post("/api/execute", json={"account_id": "A1", "phase": "buys",
                                     "dry_run": False, "plan_hash": h,
                                     "confirm_phrase": "PLACE ORDERS"})
    assert r.status_code == 409 and stub.sent == []


def test_guard_wrong_account():
    c, stub, h = _session()
    r = c.post("/api/execute", json={"account_id": "NOPE", "phase": "sells",
                                     "dry_run": False, "plan_hash": h,
                                     "confirm_phrase": "PLACE ORDERS"})
    assert r.status_code == 400 and stub.sent == []


def test_dry_run_sends_nothing():
    c, stub, h = _session()
    r = c.post("/api/execute", json={"account_id": "A1", "phase": "buys",
                                     "dry_run": True, "plan_hash": h})
    assert r.status_code == 200 and stub.sent == []
    assert all(x["detail"].startswith("dry run") for x in r.json()["results"])


def test_full_live_sequence_reaches_broker():
    c, stub, h = _session()
    base = {"account_id": "A1", "dry_run": False, "plan_hash": h,
            "confirm_phrase": "PLACE ORDERS"}
    assert c.post("/api/execute", json={**base, "phase": "sells"}).status_code == 200
    assert c.post("/api/execute", json={**base, "phase": "buys"}).status_code == 200
    assert stub.sent, "orders should reach the broker once every guard is satisfied"
    assert all(a == "BUY" for a, _, _ in stub.sent[len([s for s in stub.sent if s[0] == "SELL"]):])


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  PASS  {name}")
            except Exception as exc:
                fails += 1
                print(f"  FAIL  {name}: {exc}")
    print(f"\n{'all tests pass' if not fails else str(fails) + ' FAILURES'}")
    raise SystemExit(1 if fails else 0)
