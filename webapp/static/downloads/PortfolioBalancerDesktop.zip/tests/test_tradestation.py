"""
TradeStation adapter: environment prefill and order-status classification.

No network. `_get` is stubbed, so these exercise the parsing and the
settled/working decision -- the two places where being wrong moves money:
"settled" is what tells the person it is safe to run the buy phase.
"""
import json
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from balancer.brokers import list_brokers
from balancer.brokers.tradestation import TradeStationAdapter


# =====================================================================
# Environment prefill
# =====================================================================
TS_ENV_VARS = ["TS_API_KEY", "TS_SECRET", "TS_REFRESH_TOKEN", "TS_CLIENT_ID",
               "TS_CLIENT_SECRET", "TRADESTATION_CLIENT_ID",
               "TRADESTATION_CLIENT_SECRET", "TRADESTATION_REFRESH_TOKEN"]


@pytest.fixture
def clean_env(monkeypatch):
    for v in TS_ENV_VARS:
        monkeypatch.delenv(v, raising=False)
    return monkeypatch


def ts_fields():
    ts = next(b for b in list_brokers() if b["key"] == "tradestation")
    return {f["key"]: f for f in ts["fields"]}


def test_ts_api_key_and_secret_prefill(clean_env):
    clean_env.setenv("TS_API_KEY", "abc123")
    clean_env.setenv("TS_SECRET", "shh")
    f = ts_fields()
    assert f["client_id"]["default"] == "abc123"
    assert f["client_id"]["from_env"] == "TS_API_KEY"
    assert f["client_secret"]["default"] == "shh"
    assert f["client_secret"]["from_env"] == "TS_SECRET"
    assert "Prefilled from $TS_API_KEY" in f["client_id"]["help"]


def test_legacy_names_still_work(clean_env):
    clean_env.setenv("TRADESTATION_CLIENT_ID", "legacy")
    f = ts_fields()
    assert f["client_id"]["default"] == "legacy"
    assert f["client_id"]["from_env"] == "TRADESTATION_CLIENT_ID"


def test_new_name_wins_over_legacy(clean_env):
    clean_env.setenv("TS_API_KEY", "new")
    clean_env.setenv("TRADESTATION_CLIENT_ID", "old")
    assert ts_fields()["client_id"]["default"] == "new"


def test_unset_leaves_field_blank_and_says_so(clean_env):
    f = ts_fields()
    assert f["client_id"]["default"] == ""
    assert "from_env" not in f["client_id"]
    assert "$TS_API_KEY" in f["client_id"]["help"]
    # the refresh token is NOT covered by TS_API_KEY/TS_SECRET
    assert f["refresh_token"]["default"] == ""


def test_public_adapter_prefill_still_works(clean_env):
    clean_env.setenv("PUBLIC_API_TOKEN", "tok")
    pub = next(b for b in list_brokers() if b["key"] == "public")
    fields = {f["key"]: f for f in pub["fields"]}
    assert fields["secret"]["default"] == "tok"
    assert fields["secret"]["from_env"] == "PUBLIC_API_TOKEN"


# =====================================================================
# Order status / settled
# =====================================================================
def make_adapter(order_rows, order_ids=("111",), submitted=1):
    a = TradeStationAdapter()
    a._order_ids = list(order_ids)
    a._submitted = submitted
    a._get = lambda path: {"Orders": order_rows}
    return a


def order(oid="111", status="", desc="", sym="SPY", qty=10, filled=0):
    o = {"OrderID": oid,
         "Legs": [{"Symbol": sym, "BuyOrSell": "Sell",
                   "QuantityOrdered": qty, "ExecQuantity": filled}]}
    if status:
        o["Status"] = status
    if desc:
        o["StatusDescription"] = desc
    return o


@pytest.mark.parametrize("status,desc", [
    ("ACK", "Received"), ("OPN", "Sent"), ("DON", "Queued"),
    ("FPR", "Partial Fill (Alive)"), ("ACK", ""), ("", "Received"),
    ("WAT", "Some Future Status"),          # unknown -> must read as working
    ("", ""),                               # no status at all
])
def test_live_orders_are_not_settled(status, desc):
    """The bug this replaces: short codes never matched the long-word WORKING
    list, so every one of these reported settled while still open."""
    a = make_adapter([order(status=status, desc=desc)])
    assert a.orders_settled("A1") is False
    assert a.order_status("A1")[0]["working"] is True


@pytest.mark.parametrize("status,desc", [
    ("FLL", "Filled"), ("CAN", "Canceled"), ("REJ", "Rejected"),
    ("EXP", "Expired"), ("BRO", "Broken"), ("FLP", "Partial Fill (UROut)"),
    ("", "Filled"), ("FLL", ""),
])
def test_finished_orders_are_settled(status, desc):
    a = make_adapter([order(status=status, desc=desc, filled=10)])
    assert a.orders_settled("A1") is True
    assert a.order_status("A1")[0]["working"] is False


def test_only_this_sessions_orders_count():
    """An order placed in the TradeStation platform must not hold the buy
    phase hostage, nor appear in this app's fill log."""
    rows = [order(oid="111", status="FLL", filled=10),
            order(oid="999", status="ACK", sym="AAPL")]   # someone else's
    a = make_adapter(rows, order_ids=("111",))
    st = a.order_status("A1")
    assert [o["symbol"] for o in st] == ["SPY"]
    assert a.orders_settled("A1") is True


def test_nothing_submitted_reads_as_settled():
    a = make_adapter([order(oid="999", status="ACK")], order_ids=(), submitted=0)
    assert a.order_status("A1") == []
    assert a.orders_settled("A1") is True


def test_untrackable_orders_report_unknown_not_settled_lie():
    """Placed but no OrderID came back: the UI must be told status is unknown
    (known=False) so it tells the person to check fills themselves."""
    a = make_adapter([], order_ids=(), submitted=2)
    assert a.order_status("A1") is None
    # contract: adapters that cannot tell return True, and the UI's
    # `if (!known) return;` branch fires before it can claim "all filled"
    assert a.orders_settled("A1") is True


def test_fetch_failure_reads_as_unknown():
    from balancer.brokers import BrokerError
    a = TradeStationAdapter()
    a._order_ids, a._submitted = ["111"], 1

    def boom(path):
        raise BrokerError("500")
    a._get = boom
    assert a.order_status("A1") is None
    assert a.orders_settled("A1") is True


def test_partial_fill_is_reported_with_quantities():
    a = make_adapter([order(status="FPR", desc="Partial Fill (Alive)",
                            qty=10, filled=4)])
    st = a.order_status("A1")[0]
    assert (st["quantity"], st["filled"], st["working"]) == (10.0, 4.0, True)


def test_order_ids_reset_on_reconnect(monkeypatch):
    a = TradeStationAdapter()
    a._order_ids, a._submitted = ["stale"], 3
    monkeypatch.setattr(a, "_refresh_access", lambda: None)
    a.connect({"client_id": "x", "refresh_token": "y",
               "environment": "Simulated"})
    assert a._order_ids == [] and a._submitted == 0
    assert a.paper is True


# =====================================================================
# .env fallback and the environment diagnostic (v1.2.1)
# =====================================================================
def test_env_file_prefills_when_the_process_env_is_empty(clean_env, tmp_path,
                                                         monkeypatch):
    """The reported failure: variables set in a terminal, app launched some
    other way, nothing prefills. A .env next to the app has to cover it."""
    envf = tmp_path / ".env"
    envf.write_text('TS_API_KEY=from-file\n'
                    '# a comment\n'
                    'export TS_SECRET="quoted-secret"\n'
                    '\n'
                    'TS_REFRESH_TOKEN=rt-123\n')
    monkeypatch.setenv("BALANCER_ENV_FILE", str(envf))
    from balancer import envfile
    loaded, searched = envfile.load_env()
    assert loaded == str(envf)
    f = ts_fields()
    assert f["client_id"]["default"] == "from-file"
    assert f["client_secret"]["default"] == "quoted-secret"   # quotes stripped
    assert f["refresh_token"]["default"] == "rt-123"


def test_real_env_beats_the_file(clean_env, tmp_path, monkeypatch):
    envf = tmp_path / ".env"
    envf.write_text("TS_API_KEY=from-file\n")
    monkeypatch.setenv("BALANCER_ENV_FILE", str(envf))
    monkeypatch.setenv("TS_API_KEY", "from-real-env")
    from balancer import envfile
    envfile.load_env()
    assert ts_fields()["client_id"]["default"] == "from-real-env"


def test_env_report_never_leaks_values(clean_env, monkeypatch):
    monkeypatch.setenv("TS_API_KEY", "super-secret-value")
    from balancer.envfile import env_report
    rep = env_report(["TS_API_KEY", "TS_SECRET"])
    entry = rep["vars"]["TS_API_KEY"]
    assert entry["set"] is True and entry["length"] == 18
    assert "value" not in entry
    assert rep["vars"]["TS_SECRET"]["set"] is False
    assert "super-secret-value" not in json.dumps(rep)


def test_env_report_treats_blank_as_unset(clean_env, monkeypatch):
    """`set TS_API_KEY=` leaves an empty string; that must read as not set,
    not as 'found' with nothing in it."""
    monkeypatch.setenv("TS_API_KEY", "")
    from balancer.envfile import env_report
    assert env_report(["TS_API_KEY"])["vars"]["TS_API_KEY"]["set"] is False


def test_missing_env_file_is_not_fatal(clean_env, monkeypatch, tmp_path):
    monkeypatch.setenv("BALANCER_ENV_FILE", str(tmp_path / "nope.env"))
    from balancer import envfile
    loaded, searched = envfile.load_env()
    assert loaded == ""
    assert len(searched) >= 3          # still reports where it looked


# =====================================================================
# Windows registry fallback (v1.2.2)
# =====================================================================
def test_registry_read_is_a_noop_off_windows(monkeypatch):
    from balancer import envfile
    monkeypatch.setattr(os, "name", "posix")
    assert envfile.read_windows_env() == {}


def test_hydrate_fills_only_missing_names(clean_env, monkeypatch):
    """Simulates the reported case: TS_API_KEY/TS_SECRET exist in the Windows
    user variables but this process was started before they were created."""
    from balancer import envfile
    monkeypatch.setattr(envfile, "read_windows_env",
                        lambda: {"TS_API_KEY": "from-registry",
                                 "TS_SECRET": "reg-secret",
                                 "PATH": "SHOULD-NEVER-BE-TOUCHED"})
    before_path = os.environ.get("PATH")
    envfile.hydrate(["TS_API_KEY", "TS_SECRET"])
    assert os.environ["TS_API_KEY"] == "from-registry"
    assert os.environ["TS_SECRET"] == "reg-secret"
    # scoped to the names asked for: PATH was in the registry dict and must
    # not have been imported
    assert os.environ.get("PATH") == before_path
    assert envfile.SOURCES["TS_API_KEY"] == "registry"


def test_hydrate_does_not_override_the_real_process_env(clean_env, monkeypatch):
    from balancer import envfile
    monkeypatch.setenv("TS_API_KEY", "already-here")
    monkeypatch.setattr(envfile, "read_windows_env",
                        lambda: {"TS_API_KEY": "from-registry"})
    envfile.hydrate(["TS_API_KEY"])
    assert os.environ["TS_API_KEY"] == "already-here"


def test_list_brokers_hydrates_from_the_registry(clean_env, monkeypatch):
    """End to end: nothing in the process env, value only in the registry,
    field still prefills."""
    from balancer import envfile
    monkeypatch.setattr(envfile, "read_windows_env",
                        lambda: {"TS_API_KEY": "reg-key"})
    f = ts_fields()
    assert f["client_id"]["default"] == "reg-key"
    assert f["client_id"]["from_env"] == "TS_API_KEY"


def test_registry_key_paths_are_not_double_escaped():
    """A doubled backslash makes OpenKey raise, the except swallows it, and the
    machine-wide variables silently never load."""
    import inspect
    from balancer import envfile
    src = inspect.getsource(envfile.read_windows_env)
    assert r"SYSTEM\CurrentControlSet" in src
    assert "\\\\CurrentControlSet" not in src


def test_env_report_names_the_source(clean_env, monkeypatch):
    from balancer import envfile
    monkeypatch.setattr(envfile, "read_windows_env",
                        lambda: {"TS_SECRET": "s"})
    envfile.hydrate(["TS_SECRET"])
    rep = envfile.env_report(["TS_SECRET"])
    assert rep["vars"]["TS_SECRET"]["source"] == "registry"
    assert "value" not in rep["vars"]["TS_SECRET"]      # never echo the value


def test_trailing_space_in_the_name_is_reported(clean_env, monkeypatch):
    """A name with a trailing space looks identical in the Windows dialog and
    is a different variable. Say so instead of just 'not set'."""
    from balancer import envfile
    monkeypatch.setattr(envfile, "read_windows_env",
                        lambda: {"TS_API_KEY ": "v", "ts_secret": "v2"})
    rep = envfile.env_report(["TS_API_KEY", "TS_SECRET"])
    assert rep["vars"]["TS_API_KEY"]["set"] is False
    assert "'TS_API_KEY '" in rep["vars"]["TS_API_KEY"]["similar"]
    assert "'ts_secret'" in rep["vars"]["TS_SECRET"]["similar"]


def test_no_similar_key_when_nothing_is_close(clean_env, monkeypatch):
    from balancer import envfile
    monkeypatch.setattr(envfile, "read_windows_env", lambda: {"UNRELATED": "x"})
    rep = envfile.env_report(["TS_API_KEY"])
    assert "similar" not in rep["vars"]["TS_API_KEY"]


# =====================================================================
# OAuth redirect paste (v1.2.3)
# =====================================================================
@pytest.mark.parametrize("raw", [
    "http://localhost:3000/?code=C1&state=S1",     # what Chrome copies
    "localhost:3000/?code=C1&state=S1",            # what the bar displays
    "localhost:3000?code=C1&state=S1",             # no trailing slash
    "  http://localhost:3000/?code=C1&state=S1 ",  # stray whitespace
    "?code=C1&state=S1",                           # query only
    "code=C1&state=S1",                            # parameters alone
])
def test_every_paste_form_yields_the_code(raw):
    import urllib.parse
    qs = urllib.parse.urlparse(raw.strip()).query
    if not qs and "=" in raw.strip():
        qs = raw.strip().lstrip("?")
    p = urllib.parse.parse_qs(qs)
    assert (p.get("code") or [""])[0] == "C1"
    assert (p.get("state") or [""])[0] == "S1"


# =====================================================================
# Environment note: per-FIELD, not per-variable (v1.2.4)
# =====================================================================
def _field_state(monkeypatch, registry):
    """Reproduces renderEnvHint()'s predicate over the real /api/brokers
    payload: a field is satisfied if ANY of its accepted names supplied a
    value, and the note appears only when NONE were."""
    from balancer import envfile
    envfile.SOURCES.clear()
    monkeypatch.setattr(envfile, "read_windows_env", lambda: dict(registry))
    ts = next(b for b in list_brokers() if b["key"] == "tradestation")
    env_fields = [f for f in ts["fields"] if f.get("env") or f.get("env_alt")]
    filled = [f["key"] for f in env_fields if f.get("from_env")]
    return env_fields, filled


def test_note_is_hidden_when_any_alias_supplied_a_value(clean_env, monkeypatch):
    """The reported annoyance: TS_API_KEY and TS_SECRET were found, yet the
    banner still listed the six ALIAS names as 'not visible'."""
    env_fields, filled = _field_state(monkeypatch,
                                      {"TS_API_KEY": "k", "TS_SECRET": "s"})
    assert filled == ["client_id", "client_secret"]
    assert filled, "note must be hidden when anything prefilled"


def test_note_shows_only_when_nothing_was_found(clean_env, monkeypatch):
    env_fields, filled = _field_state(monkeypatch, {})
    assert env_fields and not filled


def test_legacy_alias_alone_also_counts_as_found(clean_env, monkeypatch):
    _, filled = _field_state(monkeypatch, {"TRADESTATION_CLIENT_ID": "k"})
    assert "client_id" in filled


def test_helper_buttons_use_the_standard_style():
    html = (Path(__file__).resolve().parent.parent / "web" / "index.html").read_text()
    for bid in ("ts-open", "ts-exchange"):
        assert f'class="btn" id="{bid}"' in html, f"{bid} should match other buttons"


# =====================================================================
# Launcher (v1.2.5)
# =====================================================================
def test_launchers_do_not_hardcode_a_bare_python():
    """`python -m venv` fails on any machine where python.exe is not on PATH --
    Anaconda installs and the Microsoft Store alias being the common cases."""
    bat = "\n".join(bat_code())
    assert "py -3 --version" in bat, "must try the Windows py launcher first"
    assert bat.count("--version") >= 3, "must probe py -3, python and python3"
    import re
    assert not re.search(r"^\s*python -m venv", bat, re.M)
    assert "%PY% -m venv" in bat
    assert "for c in python3 python" in "\n".join(sh_code())


def _code_lines(text, comment_prefixes):
    """Executable lines only. Asserting against a whole script matches its own
    comments -- which is exactly how the first version of these tests passed
    while describing behaviour the script no longer had."""
    out = []
    for line in text.splitlines():
        st = line.strip()
        if not st or any(st.lower().startswith(c) for c in comment_prefixes):
            continue
        out.append(st)
    return out


def bat_code():
    root = Path(__file__).resolve().parent.parent
    return _code_lines((root / "run.bat").read_text(), ("rem", "@rem", "::"))


def sh_code():
    root = Path(__file__).resolve().parent.parent
    return _code_lines((root / "run.sh").read_text(), ("#",))


def test_launchers_verify_the_venv_before_using_it():
    """A venv that failed to appear must stop the script, not cascade into
    three 'cannot find the path specified' errors."""
    bat = "\n".join(bat_code())
    assert 'if not exist "%VPY%" goto :venvfail' in bat
    assert bat.count("goto :venvfail") >= 2      # after create AND after rebuild
    sh = "\n".join(sh_code())
    assert sh.count("if [ ! -x .venv/bin/python ]") >= 2


def test_launchers_do_not_upgrade_pip_in_place():
    """pip uninstalling and reinstalling ITSELF is what left a new utils/ under
    an old __init__.py, dying with 'No module named
    pip._internal.utils.inject_securetransport' on the next command."""
    for label, code in (("run.bat", bat_code()), ("run.sh", sh_code())):
        for line in code:
            assert "--upgrade pip" not in line, \
                f"{label} must not self-upgrade pip: {line}"


def test_launchers_self_heal_a_broken_venv():
    bat = "\n".join(bat_code())
    assert "-m pip --version" in bat          # detect
    assert "ensurepip --upgrade" in bat       # repair
    assert "rmdir /s /q .venv" in bat         # rebuild
    sh = "\n".join(sh_code())
    assert "-m pip --version" in sh
    assert "ensurepip --upgrade" in sh
    assert "rm -rf .venv" in sh


def test_pip_failures_are_never_silenced():
    """The original bug was invisible because the upgrade wrote to nul."""
    for line in bat_code():
        if "pip install" in line:
            assert ">nul" not in line, f"pip install output must be visible: {line}"
    for line in sh_code():
        if "pip install" in line:
            assert "/dev/null" not in line, f"pip install output must be visible: {line}"
